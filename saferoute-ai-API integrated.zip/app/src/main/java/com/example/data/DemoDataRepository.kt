package com.example.data

import android.util.Log
import com.example.data.remote.LiveWeatherAlertsService
import com.example.model.AlertColor
import com.example.model.CurrentWeatherInfo
import com.example.model.DataSourceType
import com.example.model.EmergencyAlert
import com.example.model.EmergencyFacility
import com.example.model.FacilityType
import com.example.model.Hazard
import com.example.model.HazardType
import com.example.model.LiveDataState
import com.example.model.RiskLevel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Central data repository for SafeRoute AI.
 * Bridges real-time live APIs (Google Maps Platform, Open-Meteo Weather, National Weather Service)
 * with robust offline mock fallback and citizen hazard reporting.
 */
object DemoDataRepository {

    private const val TAG = "DemoDataRepository"
    private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Default sample hazards representing a regional storm/disaster scenario
    private val defaultHazards = listOf(
        Hazard(
            id = "haz-1",
            title = "Heavy Waterlogging & Flash Flooding",
            type = HazardType.FLOOD,
            locationName = "Main Road (South Sector)",
            latitude = 37.7720,
            longitude = -122.4210,
            reportedTimeAgo = "20 minutes ago",
            riskLevel = RiskLevel.HIGH,
            description = "Flooding reported 500 m ahead. Water depth exceeds 45 cm.",
            impact = "Road partially blocked. Impassable for sedans and two-wheelers.",
            roadName = "Main Road"
        ),
        Hazard(
            id = "haz-2",
            title = "Major Road Blockage & Fallen Scaffolding",
            type = HazardType.ROAD_BLOCKAGE,
            locationName = "Central Area Blvd / 4th Ave",
            latitude = 37.7780,
            longitude = -122.4150,
            reportedTimeAgo = "45 minutes ago",
            riskLevel = RiskLevel.HIGH,
            description = "Debris and construction scaffolding collapsed across lanes.",
            impact = "Both northbound lanes completely closed. Traffic standstill.",
            roadName = "Central Area Blvd"
        ),
        Hazard(
            id = "haz-3",
            title = "Multi-Vehicle Collision",
            type = HazardType.ACCIDENT,
            locationName = "Highway Junction 4 East",
            latitude = 37.7850,
            longitude = -122.4080,
            reportedTimeAgo = "15 minutes ago",
            riskLevel = RiskLevel.MEDIUM,
            description = "Three-car pileup due to slippery wet asphalt.",
            impact = "Right two lanes obstructed. Emergency crews on scene.",
            roadName = "Highway Junction 4"
        ),
        Hazard(
            id = "haz-4",
            title = "Industrial Chemical Storage Fire",
            type = HazardType.FIRE,
            locationName = "Industrial Park - Sector 9",
            latitude = 37.7630,
            longitude = -122.3990,
            reportedTimeAgo = "1 hour ago",
            riskLevel = RiskLevel.CRITICAL,
            description = "Warehouse fire producing dense smoke plume.",
            impact = "1.5 km perimeter evacuated. Complete exclusion zone.",
            roadName = "Harbour Freightway"
        ),
        Hazard(
            id = "haz-5",
            title = "Uprooted Large Oak & Power Line Down",
            type = HazardType.FALLEN_TREE,
            locationName = "North Ridge Scenic Byway",
            latitude = 37.7910,
            longitude = -122.4350,
            reportedTimeAgo = "30 minutes ago",
            riskLevel = RiskLevel.HIGH,
            description = "Heavy branches tangled in live electric cables.",
            impact = "Hazardous electrical danger. Road closed to all traffic.",
            roadName = "North Ridge Byway"
        ),
        Hazard(
            id = "haz-6",
            title = "Gale Force Wind Gusts (65 km/h)",
            type = HazardType.STRONG_WIND,
            locationName = "West Harbour Suspension Bridge",
            latitude = 37.7990,
            longitude = -122.4010,
            reportedTimeAgo = "10 minutes ago",
            riskLevel = RiskLevel.MEDIUM,
            description = "Dangerous crosswinds affecting high-profile vehicles.",
            impact = "Speed limit restricted to 25 km/h. Trucks advised to reroute.",
            roadName = "West Harbour Bridge"
        )
    )

    // Default Emergency Alerts
    private val defaultAlerts = listOf(
        EmergencyAlert(
            id = "alert-1",
            title = "RED ALERT: Complete Road Blockage on Main Road",
            alertLevel = AlertColor.RED,
            location = "Main Road & Central Cross",
            timestamp = "12 min ago",
            description = "Severe waterlogging and debris collapse have halted transit on Main Road. Emergency responders are on site.",
            recommendedAction = "Do NOT attempt to cross. Divert via Riverbank Elevated Expressway.",
            hazardType = HazardType.ROAD_BLOCKAGE
        ),
        EmergencyAlert(
            id = "alert-2",
            title = "ORANGE ALERT: Heavy Flooding in Central Area",
            alertLevel = AlertColor.ORANGE,
            location = "Central Basin Underpass",
            timestamp = "28 min ago",
            description = "Storm drain overflow has submerged the underpass up to 2 feet deep.",
            recommendedAction = "Avoid low-lying underpasses. Use high-ground routes such as Route A.",
            hazardType = HazardType.FLOOD
        ),
        EmergencyAlert(
            id = "alert-3",
            title = "YELLOW ALERT: Severe Gale Winds in Northern Sector",
            alertLevel = AlertColor.YELLOW,
            location = "Northern Bridge Corridor",
            timestamp = "45 min ago",
            description = "Wind speeds reaching 70 km/h with localized power disruptions and flying debris.",
            recommendedAction = "High-sided vehicles take alternative inland bypass. Reduce driving speed.",
            hazardType = HazardType.STRONG_WIND
        )
    )

    // Emergency Facilities
    private val defaultFacilities = listOf(
        EmergencyFacility(
            id = "fac-1",
            name = "City General Trauma & Emergency Center",
            type = FacilityType.HOSPITAL,
            address = "742 Medical Center Blvd",
            distanceKm = 1.8,
            contactNumber = "(555) 911-2000",
            statusInfo = "Emergency Room Active • Emergency Power On",
            capacityInfo = "ICU: Available • ER Wait: ~10 min"
        ),
        EmergencyFacility(
            id = "fac-2",
            name = "St. Jude Urgent Care Hospital",
            type = FacilityType.HOSPITAL,
            address = "1200 Pine Street",
            distanceKm = 3.2,
            contactNumber = "(555) 911-3400",
            statusInfo = "Operational • Triage Station Setup",
            capacityInfo = "Beds: Moderate Availability"
        ),
        EmergencyFacility(
            id = "fac-3",
            name = "North Community Civic Disaster Shelter",
            type = FacilityType.SHELTER,
            address = "500 North Civic Center Way",
            distanceKm = 2.4,
            contactNumber = "(555) 321-4455",
            statusInfo = "Open for Evacuees • Generator Backup",
            capacityInfo = "Capacity: 450 (180 spots available) • Food & Warmth"
        ),
        EmergencyFacility(
            id = "fac-4",
            name = "Central Stadium High-Capacity Evac Zone",
            type = FacilityType.SHELTER,
            address = "100 Arena Plaza",
            distanceKm = 4.1,
            contactNumber = "(555) 321-7890",
            statusInfo = "Red Cross Station Active",
            capacityInfo = "Capacity: 1,500 (800 spots available) • Pet Friendly"
        )
    )

    // Reactive State
    private val userReportedHazards = mutableListOf<Hazard>()

    private val _hazards = MutableStateFlow<List<Hazard>>(defaultHazards)
    val hazards: StateFlow<List<Hazard>> = _hazards.asStateFlow()

    private val _alerts = MutableStateFlow<List<EmergencyAlert>>(defaultAlerts)
    val alerts: StateFlow<List<EmergencyAlert>> = _alerts.asStateFlow()

    private val _facilities = MutableStateFlow<List<EmergencyFacility>>(defaultFacilities)
    val facilities: StateFlow<List<EmergencyFacility>> = _facilities.asStateFlow()

    private val _isDemoMode = MutableStateFlow(true)
    val isDemoMode: StateFlow<Boolean> = _isDemoMode.asStateFlow()

    var currentWeather: CurrentWeatherInfo? = null
        private set

    private val _liveDataState = MutableStateFlow(
        LiveDataState(
            isLoading = false,
            sourceType = DataSourceType.FALLBACK_MOCK,
            sourceName = "Simulated Emergency Scenario",
            lastUpdatedTimestamp = formatTimestamp(System.currentTimeMillis()),
            isMapsConfigured = true
        )
    )
    val liveDataState: StateFlow<LiveDataState> = _liveDataState.asStateFlow()

    init {
        // Automatically attempt to sync live meteorological & disaster data on initialization
        syncLiveData()
    }

    /**
     * Synchronizes live data from real APIs (Open-Meteo, NWS, OSRM/OpenStreetMap).
     * Gracefully falls back to realistic emergency mock data upon failure or offline conditions.
     */
    fun syncLiveData(forceFallback: Boolean = false) {
        repositoryScope.launch {
            _liveDataState.value = _liveDataState.value.copy(
                isLoading = true,
                errorMessage = null
            )

            if (forceFallback) {
                _hazards.value = userReportedHazards + defaultHazards
                _alerts.value = defaultAlerts
                _isDemoMode.value = true
                currentWeather = null
                _liveDataState.value = LiveDataState(
                    isLoading = false,
                    sourceType = DataSourceType.FALLBACK_MOCK,
                    sourceName = "Simulated Emergency Scenario",
                    lastUpdatedTimestamp = formatTimestamp(System.currentTimeMillis()),
                    isMapsConfigured = true,
                    liveWeatherSummary = "Simulated 45 mm storm cell",
                    liveTrafficSummary = "Simulated corridor restrictions"
                )
                return@launch
            }

            try {
                val weatherResult = LiveWeatherAlertsService.fetchLiveWeatherAndHazards()

                if (weatherResult.isSuccess) {
                    currentWeather = weatherResult.currentWeather

                    // Combine live hazards with any citizen reports
                    val combinedHazards = mutableListOf<Hazard>()
                    combinedHazards.addAll(userReportedHazards)
                    combinedHazards.addAll(weatherResult.hazards)

                    // Keep baseline infrastructure hazards if live returns few points
                    if (combinedHazards.size < 3) {
                        combinedHazards.addAll(defaultHazards.take(3))
                    }

                    _hazards.value = combinedHazards
                    if (weatherResult.alerts.isNotEmpty()) {
                        _alerts.value = weatherResult.alerts
                    } else {
                        _alerts.value = defaultAlerts
                    }

                    val sourceDesc = "${weatherResult.sourceName} • OpenStreetMap & OSRM Routing (Zero API Key)"

                    _isDemoMode.value = false
                    _liveDataState.value = LiveDataState(
                        isLoading = false,
                        sourceType = DataSourceType.LIVE_API,
                        sourceName = sourceDesc,
                        lastUpdatedTimestamp = formatTimestamp(System.currentTimeMillis()),
                        errorMessage = null,
                        isMapsConfigured = true,
                        liveWeatherSummary = weatherResult.weatherSummary,
                        liveTrafficSummary = "Live OSRM Routing Engine Active"
                    )
                    Log.i(TAG, "Live data synced successfully from $sourceDesc")
                } else {
                    // Fallback to offline scenario
                    Log.w(TAG, "Live weather sync did not succeed. Activating fallback: ${weatherResult.errorMessage}")
                    _hazards.value = userReportedHazards + defaultHazards
                    _alerts.value = defaultAlerts
                    _isDemoMode.value = true
                    _liveDataState.value = LiveDataState(
                        isLoading = false,
                        sourceType = DataSourceType.FALLBACK_MOCK,
                        sourceName = "Fallback Simulation (${weatherResult.errorMessage ?: "Network Timeout"})",
                        lastUpdatedTimestamp = formatTimestamp(System.currentTimeMillis()),
                        errorMessage = "Live API unavailable. Displaying verified local scenario.",
                        isMapsConfigured = true,
                        liveWeatherSummary = "Fallback Weather Simulation",
                        liveTrafficSummary = "Fallback Route Corridors"
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing live data", e)
                _hazards.value = userReportedHazards + defaultHazards
                _alerts.value = defaultAlerts
                _isDemoMode.value = true
                _liveDataState.value = LiveDataState(
                    isLoading = false,
                    sourceType = DataSourceType.FALLBACK_MOCK,
                    sourceName = "Fallback Simulation (Offline)",
                    lastUpdatedTimestamp = formatTimestamp(System.currentTimeMillis()),
                    errorMessage = e.localizedMessage ?: "Unknown network error",
                    isMapsConfigured = true
                )
            }
        }
    }

    /**
     * Allows user to report a new hazard. Updates reactive stream instantly.
     */
    fun reportHazard(
        type: HazardType,
        locationName: String,
        description: String,
        riskLevel: RiskLevel = RiskLevel.HIGH
    ): Hazard {
        val newHazard = Hazard(
            id = "user-haz-${UUID.randomUUID().toString().take(6)}",
            title = "Citizen Report: ${type.displayName}",
            type = type,
            locationName = locationName.ifBlank { "Near User Location" },
            latitude = 37.7755 + (Math.random() - 0.5) * 0.01,
            longitude = -122.4180 + (Math.random() - 0.5) * 0.01,
            reportedTimeAgo = "Just now (${formatTimestamp(System.currentTimeMillis())})",
            riskLevel = riskLevel,
            description = description.ifBlank { "Hazard reported by user in the field." },
            impact = "Caution advised in immediate perimeter.",
            roadName = locationName.ifBlank { "Local Street" },
            isUserReported = true
        )

        userReportedHazards.add(0, newHazard)
        _hazards.value = listOf(newHazard) + _hazards.value
        return newHazard
    }

    /**
     * Resets repository back to default hackathon scenario.
     */
    fun resetToDefaults() {
        userReportedHazards.clear()
        _hazards.value = defaultHazards
        _alerts.value = defaultAlerts
        _facilities.value = defaultFacilities
        _isDemoMode.value = true
        _liveDataState.value = LiveDataState(
            isLoading = false,
            sourceType = DataSourceType.FALLBACK_MOCK,
            sourceName = "Simulated Emergency Scenario",
            lastUpdatedTimestamp = formatTimestamp(System.currentTimeMillis()),
            isMapsConfigured = true
        )
    }

    private fun formatTimestamp(timeMs: Long): String {
        val sdf = SimpleDateFormat("h:mm:ss a", Locale.getDefault())
        return sdf.format(Date(timeMs))
    }
}
