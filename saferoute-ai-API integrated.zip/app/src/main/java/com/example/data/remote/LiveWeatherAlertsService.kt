package com.example.data.remote

import android.util.Log
import com.example.model.AlertColor
import com.example.model.CurrentWeatherInfo
import com.example.model.EmergencyAlert
import com.example.model.Hazard
import com.example.model.HazardType
import com.example.model.RiskLevel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

data class LiveWeatherResult(
    val isSuccess: Boolean,
    val hazards: List<Hazard> = emptyList(),
    val alerts: List<EmergencyAlert> = emptyList(),
    val weatherSummary: String = "Normal conditions",
    val sourceName: String = "Open-Meteo & National Weather Service",
    val errorMessage: String? = null,
    val currentWeather: CurrentWeatherInfo = CurrentWeatherInfo()
)

/**
 * Live meteorological hazard & severe emergency alert service.
 * Connects to Open-Meteo real-time weather models and NWS (National Weather Service) emergency bulletins.
 */
object LiveWeatherAlertsService {

    private const val TAG = "LiveWeatherAlerts"

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    /**
     * Fetches current meteorological conditions and active severe weather alerts.
     */
    suspend fun fetchLiveWeatherAndHazards(
        latitude: Double = 37.7749,
        longitude: Double = -122.4194,
        regionName: String = "Metro Region"
    ): LiveWeatherResult = withContext(Dispatchers.IO) {
        val collectedHazards = mutableListOf<Hazard>()
        val collectedAlerts = mutableListOf<EmergencyAlert>()
        var weatherSummary = "Live meteorological data synced."
        var successfulSources = mutableListOf<String>()
        var lastError: String? = null
        var parsedWeatherInfo = CurrentWeatherInfo()

        // 1. Fetch from Open-Meteo Real-Time Weather API
        try {
            val openMeteoUrl = "https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude" +
                    "&current=temperature_2m,relative_humidity_2m,precipitation,rain,showers,weather_code,wind_speed_10m,wind_gusts_10m" +
                    "&hourly=precipitation,wind_speed_10m&timezone=auto"

            val request = Request.Builder()
                .url(openMeteoUrl)
                .addHeader("Accept", "application/json")
                .build()

            val response = httpClient.newCall(request).execute()
            val body = response.body?.string()

            if (response.isSuccessful && !body.isNullOrBlank()) {
                val json = JSONObject(body)
                val current = json.optJSONObject("current")
                if (current != null) {
                    val temp = current.optDouble("temperature_2m", 18.0)
                    val humidity = current.optInt("relative_humidity_2m", 70)
                    val precip = current.optDouble("precipitation", 0.0)
                    val rain = current.optDouble("rain", 0.0)
                    val windSpeed = current.optDouble("wind_speed_10m", 12.0)
                    val windGusts = current.optDouble("wind_gusts_10m", windSpeed * 1.3)
                    val weatherCode = current.optInt("weather_code", 0)

                    val weatherCondition = interpretWeatherCode(weatherCode)
                    weatherSummary = "$weatherCondition, ${temp.toInt()}°C • Wind: ${windSpeed.toInt()} km/h (Gusts: ${windGusts.toInt()} km/h)"

                    // Calculate weather penalty for safety score
                    val deduction = when {
                        weatherCode in listOf(95, 96, 99) || precip >= 8.0 || windGusts >= 65.0 -> 25
                        weatherCode in listOf(65, 82) || precip >= 4.0 || windGusts >= 45.0 -> 15
                        weatherCode in listOf(61, 63, 81) || precip >= 1.5 || windSpeed >= 30.0 -> 8
                        else -> 0
                    }

                    parsedWeatherInfo = CurrentWeatherInfo(
                        temperatureC = temp,
                        relativeHumidity = humidity,
                        precipitationMm = precip,
                        rainMm = rain,
                        windSpeedKmh = windSpeed,
                        windGustsKmh = windGusts,
                        weatherCode = weatherCode,
                        conditionDescription = weatherCondition,
                        forecastSummary = if (precip > 0.5) "Active precipitation $precip mm/h" else "Favorable road traction",
                        weatherRiskDeduction = deduction
                    )

                    // Check for severe wind hazard
                    if (windGusts >= 45.0) {
                        val risk = if (windGusts >= 70.0) RiskLevel.CRITICAL else if (windGusts >= 55.0) RiskLevel.HIGH else RiskLevel.MEDIUM
                        collectedHazards.add(
                            Hazard(
                                id = "live-wind-${UUID.randomUUID().toString().take(6)}",
                                title = "High Wind Hazard (${windGusts.toInt()} km/h Gusts)",
                                type = HazardType.STRONG_WIND,
                                locationName = "$regionName Wind Corridor",
                                latitude = latitude + 0.008,
                                longitude = longitude - 0.005,
                                reportedTimeAgo = "Live Sensor (${currentTimeFormatted()})",
                                riskLevel = risk,
                                description = "Live weather telemetry reports dangerous crosswind gusts reaching ${windGusts.toInt()} km/h.",
                                impact = "Risk to high-sided vehicles, falling branches, and utility lines. Reduce speed.",
                                roadName = "West Harbour & Highway Overpass"
                            )
                        )
                        collectedAlerts.add(
                            EmergencyAlert(
                                id = "alert-wind-${UUID.randomUUID().toString().take(6)}",
                                title = "${if (risk == RiskLevel.CRITICAL) "RED" else "ORANGE"} ALERT: Severe Wind Warning",
                                alertLevel = if (risk == RiskLevel.CRITICAL) AlertColor.RED else AlertColor.ORANGE,
                                location = "$regionName Highway & Bridge Corridors",
                                timestamp = currentTimeFormatted(),
                                description = "Dangerous wind gusts detected at ${windGusts.toInt()} km/h. High risk of debris and vehicle instability.",
                                recommendedAction = "Take sheltered inland routes. Avoid elevated bridges.",
                                hazardType = HazardType.STRONG_WIND
                            )
                        )
                    }

                    // Check for flood / rain hazard
                    if (precip >= 2.0 || rain >= 2.0 || weatherCode in listOf(65, 81, 82, 95, 96, 99)) {
                        val risk = if (precip >= 10.0 || weatherCode in listOf(96, 99)) RiskLevel.CRITICAL
                        else if (precip >= 4.0 || weatherCode == 95) RiskLevel.HIGH
                        else RiskLevel.MEDIUM

                        collectedHazards.add(
                            Hazard(
                                id = "live-flood-${UUID.randomUUID().toString().take(6)}",
                                title = if (precip >= 8.0) "Flash Flood & Waterlogging Hazard" else "Heavy Rain & Standing Water Risk",
                                type = HazardType.FLOOD,
                                locationName = "$regionName Low-Lying Basin",
                                latitude = latitude - 0.006,
                                longitude = longitude + 0.004,
                                reportedTimeAgo = "Live Sensor (${currentTimeFormatted()})",
                                riskLevel = risk,
                                description = "Active precipitation of ${String.format(Locale.US, "%.1f", precip)} mm/h detected. Runoff pooling in underpasses and low ground.",
                                impact = "Reduced visibility and severe hydroplaning danger. Submerged pavement possible.",
                                roadName = "Main Road Corridor & Underpasses"
                            )
                        )
                        collectedAlerts.add(
                            EmergencyAlert(
                                id = "alert-flood-${UUID.randomUUID().toString().take(6)}",
                                title = "${if (risk == RiskLevel.CRITICAL) "RED" else "ORANGE"} ALERT: Active Precipitation & Flooding Advisory",
                                alertLevel = if (risk == RiskLevel.CRITICAL) AlertColor.RED else AlertColor.ORANGE,
                                location = "$regionName Drainage Basins",
                                timestamp = currentTimeFormatted(),
                                description = "Live radar shows persistent heavy rain bands over the regional transit network.",
                                recommendedAction = "Divert to elevated routes (Route A). Never drive into flooded dips.",
                                hazardType = HazardType.FLOOD
                            )
                        )
                    }

                    // Check for severe thunderstorm / squall code
                    if (weatherCode in listOf(95, 96, 99)) {
                        collectedHazards.add(
                            Hazard(
                                id = "live-storm-${UUID.randomUUID().toString().take(6)}",
                                title = "Severe Thunderstorm & Lightning Hazard",
                                type = HazardType.OTHER,
                                locationName = "$regionName Transit Core",
                                latitude = latitude + 0.004,
                                longitude = longitude + 0.002,
                                reportedTimeAgo = "Live Radar (${currentTimeFormatted()})",
                                riskLevel = RiskLevel.HIGH,
                                description = "Active convective thunderstorm cell directly impacting the urban perimeter.",
                                impact = "Zero visibility, potential lightning strikes, downed signs.",
                                roadName = "Central Transit Arterial"
                            )
                        )
                    }

                    successfulSources.add("Open-Meteo Weather API")
                }
            } else {
                lastError = "Open-Meteo returned status ${response.code}"
            }
        } catch (e: Exception) {
            Log.w(TAG, "Open-Meteo fetch failed", e)
            lastError = e.localizedMessage
        }

        // 2. Fetch from National Weather Service (NWS) Active Alerts API
        try {
            val nwsUrl = "https://api.weather.gov/alerts/active?status=actual&message_type=alert&limit=5"
            val request = Request.Builder()
                .url(nwsUrl)
                .addHeader("User-Agent", "SafeRouteAI/1.0 (Disaster-Resilient Navigation; contact@saferoute.ai)")
                .addHeader("Accept", "application/geo+json")
                .build()

            val response = httpClient.newCall(request).execute()
            val body = response.body?.string()

            if (response.isSuccessful && !body.isNullOrBlank()) {
                val json = JSONObject(body)
                val features = json.optJSONArray("features")
                if (features != null) {
                    val count = minOf(features.length(), 4)
                    for (i in 0 until count) {
                        val feat = features.getJSONObject(i)
                        val props = feat.optJSONObject("properties") ?: continue

                        val event = props.optString("event", "Severe Weather Alert")
                        val headline = props.optString("headline", event)
                        val severity = props.optString("severity", "Moderate")
                        val desc = props.optString("description", "")
                        val instruction = props.optString("instruction", "Follow local authority guidance.")
                        val areaDesc = props.optString("areaDesc", regionName)

                        val risk = when (severity.lowercase(Locale.ROOT)) {
                            "extreme" -> RiskLevel.CRITICAL
                            "severe" -> RiskLevel.HIGH
                            else -> RiskLevel.MEDIUM
                        }

                        val alertColor = when (risk) {
                            RiskLevel.CRITICAL -> AlertColor.RED
                            RiskLevel.HIGH -> AlertColor.ORANGE
                            else -> AlertColor.YELLOW
                        }

                        val hazardType = when {
                            event.contains("flood", ignoreCase = true) -> HazardType.FLOOD
                            event.contains("fire", ignoreCase = true) -> HazardType.FIRE
                            event.contains("wind", ignoreCase = true) -> HazardType.STRONG_WIND
                            event.contains("debris", ignoreCase = true) || event.contains("tree", ignoreCase = true) -> HazardType.FALLEN_TREE
                            else -> HazardType.OTHER
                        }

                        collectedAlerts.add(
                            EmergencyAlert(
                                id = "nws-${props.optString("id", UUID.randomUUID().toString().take(6))}",
                                title = "${alertColor.title}: $event",
                                alertLevel = alertColor,
                                location = areaDesc.take(40),
                                timestamp = currentTimeFormatted(),
                                description = if (desc.isNotBlank()) desc.take(200) + "..." else headline,
                                recommendedAction = if (instruction.isNotBlank()) instruction.take(150) + "..." else "Proceed with extreme caution.",
                                hazardType = hazardType
                            )
                        )

                        collectedHazards.add(
                            Hazard(
                                id = "nws-haz-${UUID.randomUUID().toString().take(6)}",
                                title = "NWS Bulletin: $event",
                                type = hazardType,
                                locationName = areaDesc.take(35),
                                latitude = latitude + (Math.random() - 0.5) * 0.02,
                                longitude = longitude + (Math.random() - 0.5) * 0.02,
                                reportedTimeAgo = "NWS Live (${currentTimeFormatted()})",
                                riskLevel = risk,
                                description = headline.ifBlank { "Official National Weather Service emergency alert." },
                                impact = instruction.take(120).ifBlank { "Exercise extreme caution along exposed roads." },
                                roadName = "Regional Road Network"
                            )
                        )
                    }
                    successfulSources.add("NWS Active Alerts")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "NWS API fetch failed", e)
        }

        val hasLiveResults = collectedHazards.isNotEmpty() || collectedAlerts.isNotEmpty() || successfulSources.isNotEmpty()

        LiveWeatherResult(
            isSuccess = hasLiveResults,
            hazards = collectedHazards,
            alerts = collectedAlerts,
            weatherSummary = weatherSummary,
            sourceName = if (successfulSources.isNotEmpty()) successfulSources.joinToString(" • ") else "Live Weather APIs",
            errorMessage = if (!hasLiveResults) (lastError ?: "Failed to connect to weather APIs") else null,
            currentWeather = parsedWeatherInfo
        )
    }

    private fun interpretWeatherCode(code: Int): String {
        return when (code) {
            0 -> "Clear Skies"
            1, 2, 3 -> "Partly Cloudy"
            45, 48 -> "Dense Fog"
            51, 53, 55 -> "Light Drizzle"
            61, 63 -> "Moderate Rain"
            65 -> "Heavy Downpour"
            66, 67 -> "Freezing Rain"
            71, 73, 75 -> "Snowfall"
            80, 81, 82 -> "Rain Showers"
            95 -> "Thunderstorm Active"
            96, 99 -> "Severe Thunderstorm with Hail"
            else -> "Variable Weather"
        }
    }

    private fun currentTimeFormatted(): String {
        val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
        return sdf.format(Date())
    }
}
