package com.example.data.remote

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * Parsed route from Open Source Routing Machine (OSRM).
 * Completely open, 100% free, requiring NO API key and NO credit card.
 */
data class ParsedOsrmRoute(
    val summary: String,
    val distanceKm: Double,
    val durationMin: Int,
    val roadNames: List<String>,
    val checkpoints: List<String>,
    val coordinates: List<Pair<Double, Double>> // (lat, lon)
)

data class OsrmResult(
    val isSuccess: Boolean,
    val routes: List<ParsedOsrmRoute> = emptyList(),
    val startCoord: Pair<Double, Double> = Pair(37.7749, -122.4194),
    val destCoord: Pair<Double, Double> = Pair(37.7850, -122.4080),
    val errorMessage: String? = null
)

/**
 * OSRM Routing Service using OpenStreetMap data.
 * Replaces Google Maps Directions API without requiring a credit card or MAPS_API_KEY.
 */
object OsrmApiService {

    private const val TAG = "OsrmApiService"
    private const val OSRM_BASE_URL = "https://router.project-osrm.org/route/v1/driving"

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    // Pre-mapped landmarks in demo metropolitan zone for fast, offline-resilient lookup
    private val knownLandmarks = mapOf(
        "metro central" to Pair(37.7749, -122.4194),
        "current location" to Pair(37.7749, -122.4194),
        "city centre" to Pair(37.7850, -122.4080),
        "general hospital" to Pair(37.7550, -122.4050),
        "north shelter" to Pair(37.7980, -122.4200),
        "airport road" to Pair(37.6213, -122.3790),
        "west harbour" to Pair(37.8050, -122.4450),
        "industrial park" to Pair(37.7630, -122.3990),
        "south sector" to Pair(37.7200, -122.4300),
        "highland shelter" to Pair(37.8010, -122.4100)
    )

    /**
     * Resolves location name to latitude/longitude coordinates using known landmarks
     * or OpenStreetMap Nominatim geocoder.
     */
    suspend fun resolveCoordinates(locationName: String, fallback: Pair<Double, Double>): Pair<Double, Double> = withContext(Dispatchers.IO) {
        val cleanName = locationName.trim().lowercase()
        for ((key, coord) in knownLandmarks) {
            if (cleanName.contains(key) || key.contains(cleanName)) {
                return@withContext coord
            }
        }

        // Try OpenStreetMap Nominatim geocoder with standard User-Agent
        try {
            val encodedQuery = URLEncoder.encode(locationName, "UTF-8")
            val nominatimUrl = "https://nominatim.openstreetmap.org/search?q=$encodedQuery&format=json&limit=1"
            val request = Request.Builder()
                .url(nominatimUrl)
                .header("User-Agent", "SafeRouteAI-EmergencyNav/1.0 (open-access)")
                .build()

            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string()
                if (!body.isNullOrBlank()) {
                    val array = JSONArray(body)
                    if (array.length() > 0) {
                        val first = array.getJSONObject(0)
                        val lat = first.getDouble("lat")
                        val lon = first.getDouble("lon")
                        return@withContext Pair(lat, lon)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Nominatim geocoding lookup failed for '$locationName': ${e.message}")
        }

        fallback
    }

    /**
     * Calculates routes via OSRM with alternative corridors.
     */
    suspend fun calculateRoutes(
        startName: String = "Metro Central",
        destName: String = "City Centre"
    ): OsrmResult = withContext(Dispatchers.IO) {
        try {
            val startCoord = resolveCoordinates(startName, Pair(37.7749, -122.4194))
            val destCoord = resolveCoordinates(destName, Pair(37.7850, -122.4080))

            val lon1 = startCoord.second
            val lat1 = startCoord.first
            val lon2 = destCoord.second
            val lat2 = destCoord.first

            // OSRM expects {lon1},{lat1};{lon2},{lat2}
            val osrmUrl = "$OSRM_BASE_URL/$lon1,$lat1;$lon2,$lat2?overview=full&geometries=geojson&alternatives=true&steps=true"

            Log.i(TAG, "Calling OSRM Route API: $osrmUrl")
            val request = Request.Builder()
                .url(osrmUrl)
                .header("User-Agent", "SafeRouteAI-EmergencyNav/1.0 (open-access)")
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext OsrmResult(
                    isSuccess = false,
                    startCoord = startCoord,
                    destCoord = destCoord,
                    errorMessage = "OSRM Routing HTTP error: ${response.code}"
                )
            }

            val body = response.body?.string() ?: return@withContext OsrmResult(
                isSuccess = false,
                startCoord = startCoord,
                destCoord = destCoord,
                errorMessage = "Empty response from OSRM"
            )

            val json = JSONObject(body)
            val code = json.optString("code", "")
            if (code != "Ok") {
                return@withContext OsrmResult(
                    isSuccess = false,
                    startCoord = startCoord,
                    destCoord = destCoord,
                    errorMessage = "OSRM error: ${json.optString("message", code)}"
                )
            }

            val routesJson = json.optJSONArray("routes") ?: JSONArray()
            val parsedRoutes = mutableListOf<ParsedOsrmRoute>()

            for (i in 0 until routesJson.length()) {
                val rObj = routesJson.getJSONObject(i)
                val distMeters = rObj.optDouble("distance", 0.0)
                val durationSec = rObj.optDouble("duration", 0.0)
                val distKm = ((distMeters / 1000.0) * 10.0).roundToInt() / 10.0
                val durationMin = (durationSec / 60.0).roundToInt().coerceAtLeast(1)

                // Parse geometry coordinates [[lon, lat], ...]
                val coordinates = mutableListOf<Pair<Double, Double>>()
                val geometryObj = rObj.optJSONObject("geometry")
                val coordsArray = geometryObj?.optJSONArray("coordinates")
                if (coordsArray != null) {
                    for (c in 0 until coordsArray.length()) {
                        val pt = coordsArray.getJSONArray(c)
                        val lon = pt.getDouble(0)
                        val lat = pt.getDouble(1)
                        coordinates.add(Pair(lat, lon))
                    }
                }

                // Parse legs and turn-by-turn steps
                val roadNames = mutableSetOf<String>()
                val checkpoints = mutableListOf<String>()
                var routeSummary = "Corridor ${('A' + i)}"

                val legsArray = rObj.optJSONArray("legs")
                if (legsArray != null && legsArray.length() > 0) {
                    val leg = legsArray.getJSONObject(0)
                    val legSummary = leg.optString("summary", "")
                    if (legSummary.isNotBlank()) {
                        routeSummary = legSummary
                        roadNames.add(legSummary)
                    }

                    val steps = leg.optJSONArray("steps")
                    if (steps != null) {
                        for (s in 0 until steps.length()) {
                            val step = steps.getJSONObject(s)
                            val stepName = step.optString("name", "")
                            if (stepName.isNotBlank() && !roadNames.contains(stepName)) {
                                roadNames.add(stepName)
                            }
                            val maneuver = step.optJSONObject("maneuver")
                            val instruction = maneuver?.optString("type", "") ?: ""
                            val modifier = maneuver?.optString("modifier", "") ?: ""
                            if (stepName.isNotBlank() && checkpoints.size < 6) {
                                val action = if (modifier.isNotBlank()) "$instruction $modifier onto $stepName" else "Follow $stepName"
                                checkpoints.add(action)
                            }
                        }
                    }
                }

                if (checkpoints.isEmpty()) {
                    checkpoints.add("Depart $startName")
                    checkpoints.add("Proceed via $routeSummary")
                    checkpoints.add("Arrive at $destName")
                }

                parsedRoutes.add(
                    ParsedOsrmRoute(
                        summary = routeSummary,
                        distanceKm = distKm,
                        durationMin = durationMin,
                        roadNames = roadNames.toList(),
                        checkpoints = checkpoints,
                        coordinates = coordinates
                    )
                )
            }

            OsrmResult(
                isSuccess = parsedRoutes.isNotEmpty(),
                routes = parsedRoutes,
                startCoord = startCoord,
                destCoord = destCoord
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to compute routes via OSRM", e)
            OsrmResult(
                isSuccess = false,
                errorMessage = e.localizedMessage ?: "Unknown network error connecting to OSRM"
            )
        }
    }
}
