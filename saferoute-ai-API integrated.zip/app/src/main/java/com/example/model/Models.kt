package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CarCrash
import androidx.compose.material.icons.filled.Forest
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Water
import androidx.compose.material.icons.filled.Air
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.theme.CautionOrange
import com.example.ui.theme.DangerRed
import com.example.ui.theme.SafeGreen

/**
 * Types of hazards tracked by SafeRoute AI during emergencies.
 */
enum class HazardType(val displayName: String) {
    FLOOD("Flooding"),
    FIRE("Active Fire"),
    ACCIDENT("Severe Accident"),
    ROAD_BLOCKAGE("Road Blockage"),
    FALLEN_TREE("Fallen Tree/Debris"),
    STRONG_WIND("Severe Wind"),
    OTHER("Emergency Hazard");

    fun getIcon(): ImageVector = when (this) {
        FLOOD -> Icons.Default.Water
        FIRE -> Icons.Default.LocalFireDepartment
        ACCIDENT -> Icons.Default.CarCrash
        ROAD_BLOCKAGE -> Icons.Default.Block
        FALLEN_TREE -> Icons.Default.Forest
        STRONG_WIND -> Icons.Default.Air
        OTHER -> Icons.Default.Warning
    }
}

/**
 * Severity / Risk rating for hazards and route impact.
 */
enum class RiskLevel(val label: String, val scoreDeduction: Int, val color: Color) {
    LOW("Low", 10, SafeGreen),
    MEDIUM("Medium", 25, CautionOrange),
    HIGH("High", 45, DangerRed),
    CRITICAL("Critical", 65, DangerRed)
}

/**
 * A reported or detected hazard point on the map.
 */
data class Hazard(
    val id: String,
    val title: String,
    val type: HazardType,
    val locationName: String,
    val latitude: Double,
    val longitude: Double,
    val reportedTimeAgo: String,
    val riskLevel: RiskLevel,
    val description: String,
    val impact: String,
    val roadName: String,
    val isUserReported: Boolean = false
)

/**
 * Color-coded emergency alerts broadcast to citizens.
 */
enum class AlertColor(val title: String, val color: Color) {
    RED("RED ALERT", DangerRed),
    ORANGE("ORANGE ALERT", CautionOrange),
    YELLOW("YELLOW ALERT", Color(0xFFEAB308))
}

/**
 * Emergency alert published by disaster management authorities.
 */
data class EmergencyAlert(
    val id: String,
    val title: String,
    val alertLevel: AlertColor,
    val location: String,
    val timestamp: String,
    val description: String,
    val recommendedAction: String,
    val hazardType: HazardType
)

/**
 * Safety categorization for navigational routes.
 */
enum class RouteStatus(val label: String, val color: Color) {
    SAFE("SAFE", SafeGreen),
    CAUTION("CAUTION", CautionOrange),
    DANGER("DANGER", DangerRed)
}

/**
 * An evaluated navigational route with safety scoring from OSRM & OpenStreetMap.
 */
data class RouteOption(
    val id: String,
    val name: String,
    val viaRoads: String,
    val safetyScore: Int,
    val distanceKm: Double,
    val estimatedTimeMin: Int,
    val status: RouteStatus,
    val isRecommended: Boolean,
    val hazardsEncountered: List<String>,
    val explanation: String,
    val checkpoints: List<String>,
    val isFastest: Boolean = false,
    val coordinates: List<Pair<Double, Double>> = emptyList()
)

/**
 * Real-time meteorological telemetry from Open-Meteo.
 */
data class CurrentWeatherInfo(
    val temperatureC: Double = 18.0,
    val relativeHumidity: Int = 75,
    val precipitationMm: Double = 0.0,
    val rainMm: Double = 0.0,
    val windSpeedKmh: Double = 15.0,
    val windGustsKmh: Double = 22.0,
    val weatherCode: Int = 0,
    val conditionDescription: String = "Clear / Overcast",
    val forecastSummary: String = "Normal conditions",
    val weatherRiskDeduction: Int = 0
)

/**
 * Types of disaster relief facilities.
 */
enum class FacilityType {
    HOSPITAL,
    SHELTER,
    FIRE_STATION,
    POLICE
}

/**
 * Nearby critical emergency support facilities (hospitals, storm shelters).
 */
data class EmergencyFacility(
    val id: String,
    val name: String,
    val type: FacilityType,
    val address: String,
    val distanceKm: Double,
    val contactNumber: String,
    val statusInfo: String,
    val capacityInfo: String
)

/**
 * Message in the SafeRoute Assistant chat.
 */
enum class MessageSender {
    USER,
    ASSISTANT
}

data class ChatMessage(
    val id: String,
    val sender: MessageSender,
    val text: String,
    val timestamp: String,
    val suggestedPrompts: List<String> = emptyList()
)

/**
 * Data provenance indicator for live disaster and route data.
 */
enum class DataSourceType(val label: String) {
    LIVE_API("Live APIs"),
    FALLBACK_MOCK("Fallback Data")
}

/**
 * Real-time synchronization state for weather, hazard, and route feeds.
 */
data class LiveDataState(
    val isLoading: Boolean = false,
    val sourceType: DataSourceType = DataSourceType.FALLBACK_MOCK,
    val sourceName: String = "Simulated Emergency Scenario",
    val lastUpdatedTimestamp: String = "Just now",
    val errorMessage: String? = null,
    val isMapsConfigured: Boolean = false,
    val liveWeatherSummary: String? = null,
    val liveTrafficSummary: String? = null
)
