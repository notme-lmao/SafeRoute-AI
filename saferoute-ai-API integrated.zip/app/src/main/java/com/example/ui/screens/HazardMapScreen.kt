package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoDataRepository
import com.example.logic.RouteManager
import com.example.model.Hazard
import com.example.model.HazardType
import com.example.model.RiskLevel
import com.example.model.RouteOption
import com.example.ui.components.HazardDetailDialog
import com.example.ui.components.LeafletOsmMapView
import com.example.ui.components.LiveDataStatusPill
import com.example.ui.theme.BrandSky
import com.example.ui.theme.BrandTeal
import com.example.ui.theme.BrandTealLight
import com.example.ui.theme.CautionOrange
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.SafeGreen
import kotlinx.coroutines.launch

/**
 * Visual interactive map showing real-time emergency hazard perimeters,
 * route corridors, risk zones, and user position.
 */
@Composable
fun HazardMapScreen(
    onReportHazard: () -> Unit,
    onNavigateSafeRoute: () -> Unit,
    modifier: Modifier = Modifier
) {
    val hazards by DemoDataRepository.hazards.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    var selectedHazard by remember { mutableStateOf<Hazard?>(null) }
    var selectedFilterType by remember { mutableStateOf<HazardType?>(null) }
    var showSafeRouteOverlay by remember { mutableStateOf(true) }
    var useLeafletMap by remember { mutableStateOf(true) }

    var destinationInput by remember { mutableStateOf("City Centre") }
    var activeDestination by remember { mutableStateOf("City Centre") }
    var destCoordinates by remember { mutableStateOf(Pair(37.7850, -122.4080)) }
    var routeCoordinates by remember { mutableStateOf<List<Pair<Double, Double>>>(emptyList()) }
    var computedRoutes by remember { mutableStateOf<List<RouteOption>>(emptyList()) }
    var isCalculatingRoute by remember { mutableStateOf(false) }

    fun calculateRoutesFor(dest: String) {
        activeDestination = dest
        isCalculatingRoute = true

        destCoordinates = when {
            dest.contains("Harbour", ignoreCase = true) -> Pair(37.8080, -122.4177)
            dest.contains("Medical", ignoreCase = true) || dest.contains("Hospital", ignoreCase = true) -> Pair(37.7630, -122.4580)
            dest.contains("Industrial", ignoreCase = true) -> Pair(37.7580, -122.3890)
            dest.contains("Park", ignoreCase = true) -> Pair(37.7690, -122.4860)
            else -> Pair(37.7850, -122.4080)
        }

        coroutineScope.launch {
            try {
                val routes = RouteManager.computeLiveSafeRoutes("Metro Central", dest)
                computedRoutes = routes
                val recommended = routes.firstOrNull { it.isRecommended } ?: routes.firstOrNull()
                if (recommended != null && recommended.coordinates.isNotEmpty()) {
                    routeCoordinates = recommended.coordinates
                }
            } catch (e: Exception) {
                val fallback = RouteManager.findSafeRoutes("Metro Central", dest)
                computedRoutes = fallback
                routeCoordinates = fallback.firstOrNull()?.coordinates ?: emptyList()
            } finally {
                isCalculatingRoute = false
            }
        }
    }

    LaunchedEffect(hazards) {
        calculateRoutesFor(activeDestination)
    }

    val filteredHazards = if (selectedFilterType == null) {
        hazards
    } else {
        hazards.filter { it.type == selectedFilterType }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 18f,
        targetValue = 38f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseRadius"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseAlpha"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("hazard_map_screen")
    ) {
        if (useLeafletMap) {
            LeafletOsmMapView(
                hazards = filteredHazards,
                selectedHazard = selectedHazard,
                userLocation = Pair(37.7749, -122.4194),
                destinationLocation = destCoordinates,
                destinationName = activeDestination,
                routeCoordinates = if (showSafeRouteOverlay) routeCoordinates else emptyList(),
                onHazardSelected = { selectedHazard = it },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Map Canvas (Tactical Radar View)
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                .pointerInput(filteredHazards) {
                    detectTapGestures { tapOffset ->
                        // Detect if user tapped near any hazard
                        val w = size.width
                        val h = size.height

                        // Calculate nearest hazard
                        var nearest: Hazard? = null
                        var minDist = Float.MAX_VALUE

                        filteredHazards.forEach { haz ->
                            val (normX, normY) = getNormalizedCoordinates(haz)
                            val pinX = normX * w
                            val pinY = normY * h
                            val dist = Math.hypot((tapOffset.x - pinX).toDouble(), (tapOffset.y - pinY).toDouble()).toFloat()
                            if (dist < 48.dp.toPx() && dist < minDist) {
                                minDist = dist
                                nearest = haz
                            }
                        }

                        if (nearest != null) {
                            selectedHazard = nearest
                        }
                    }
                }
        ) {
            val w = size.width
            val h = size.height

            // 1. Background Grid & City Layout
            drawRect(color = Color(0xFF0F172A)) // Deep Map Navy

            // Minor grid streets
            val gridStep = 45.dp.toPx()
            var gx = 0f
            while (gx < w) {
                drawLine(
                    color = Color(0xFF1E293B).copy(alpha = 0.6f),
                    start = Offset(gx, 0f),
                    end = Offset(gx, h),
                    strokeWidth = 1.dp.toPx()
                )
                gx += gridStep
            }
            var gy = 0f
            while (gy < h) {
                drawLine(
                    color = Color(0xFF1E293B).copy(alpha = 0.6f),
                    start = Offset(0f, gy),
                    end = Offset(w, gy),
                    strokeWidth = 1.dp.toPx()
                )
                gy += gridStep
            }

            // 2. River / Waterway
            val riverPath = Path().apply {
                moveTo(0f, h * 0.35f)
                cubicTo(w * 0.3f, h * 0.38f, w * 0.6f, h * 0.28f, w, h * 0.42f)
                lineTo(w, h * 0.48f)
                cubicTo(w * 0.6f, h * 0.34f, w * 0.3f, h * 0.44f, 0f, h * 0.41f)
                close()
            }
            drawPath(
                path = riverPath,
                color = Color(0xFF0284C7).copy(alpha = 0.25f)
            )

            // 3. Primary Roads
            // Main Road (Corridor with active flood)
            val mainRoadPath = Path().apply {
                moveTo(w * 0.25f, h * 0.15f)
                lineTo(w * 0.35f, h * 0.45f)
                lineTo(w * 0.45f, h * 0.85f)
            }
            drawPath(
                path = mainRoadPath,
                color = CautionOrange.copy(alpha = 0.7f),
                style = Stroke(
                    width = 6.dp.toPx(),
                    cap = StrokeCap.Round,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 12f))
                )
            )

            // Central Avenue East-West
            drawLine(
                color = Color(0xFF334155),
                start = Offset(0f, h * 0.55f),
                end = Offset(w, h * 0.55f),
                strokeWidth = 5.dp.toPx(),
                cap = StrokeCap.Round
            )

            // 4. Safe Route A (Elevated Bypass)
            if (showSafeRouteOverlay) {
                val routeAPath = Path().apply {
                    // Start from Metro Central (w*0.25, h*0.2)
                    moveTo(w * 0.25f, h * 0.2f)
                    cubicTo(w * 0.15f, h * 0.3f, w * 0.18f, h * 0.65f, w * 0.32f, h * 0.75f)
                    lineTo(w * 0.75f, h * 0.75f)
                }

                // Glowing background for safe path
                drawPath(
                    path = routeAPath,
                    color = SafeGreen.copy(alpha = 0.35f),
                    style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )

                // Foreground solid green path
                drawPath(
                    path = routeAPath,
                    color = SafeGreen,
                    style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }

            // 5. Hazard Exclusion Zones & Pins
            filteredHazards.forEach { hazard ->
                val (normX, normY) = getNormalizedCoordinates(hazard)
                val pinCenter = Offset(normX * w, normY * h)

                val riskColor = when (hazard.riskLevel) {
                    RiskLevel.LOW -> SafeGreen
                    RiskLevel.MEDIUM -> CautionOrange
                    RiskLevel.HIGH, RiskLevel.CRITICAL -> DangerRed
                }

                // Pulsing hazard danger radius
                drawCircle(
                    color = riskColor.copy(alpha = pulseAlpha),
                    radius = pulseRadius * density,
                    center = pinCenter
                )

                // Hazard buffer zone
                drawCircle(
                    color = riskColor.copy(alpha = 0.22f),
                    radius = 24.dp.toPx(),
                    center = pinCenter
                )

                // Pin Base circle
                drawCircle(
                    color = riskColor,
                    radius = 12.dp.toPx(),
                    center = pinCenter
                )

                // Inner white circle
                drawCircle(
                    color = Color.White,
                    radius = 5.dp.toPx(),
                    center = pinCenter
                )
            }

            // 6. User Current Location Pin (Metro Central)
            val userCenter = Offset(w * 0.25f, h * 0.2f)
            drawCircle(
                color = BrandSky.copy(alpha = pulseAlpha),
                radius = (pulseRadius + 10) * density,
                center = userCenter
            )
            drawCircle(
                color = BrandSky.copy(alpha = 0.3f),
                radius = 18.dp.toPx(),
                center = userCenter
            )
            drawCircle(
                color = BrandSky,
                radius = 8.dp.toPx(),
                center = userCenter
            )
            drawCircle(
                color = Color.White,
                radius = 3.dp.toPx(),
                center = userCenter
            )

            // 7. Destination Pin (City Centre)
            val destCenter = Offset(w * 0.75f, h * 0.75f)
            drawCircle(
                color = Color(0xFFEAB308).copy(alpha = 0.25f),
                radius = 20.dp.toPx(),
                center = destCenter
            )
            drawCircle(
                color = Color(0xFFEAB308),
                radius = 9.dp.toPx(),
                center = destCenter
            )
            drawCircle(
                color = Color.Black,
                radius = 4.dp.toPx(),
                center = destCenter
            )
        }
    }

        // Top Overlay: Filter Bar & Safe Route Toggle
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .align(Alignment.TopCenter)
        ) {
            // Map Controls Card
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (useLeafletMap) "OpenStreetMap (Leaflet)" else "Tactical Radar",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                LiveDataStatusPill()
                            }
                            Text(
                                text = "OSRM Live Routes • Zero API Key Needed",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clickable { useLeafletMap = !useLeafletMap }
                                    .padding(2.dp)
                                    .testTag("map_mode_toggle")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (useLeafletMap) Icons.Default.Map else Icons.Default.Layers,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = if (useLeafletMap) "OSM" else "Radar",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            IconButton(
                                onClick = { DemoDataRepository.syncLiveData() },
                                modifier = Modifier.size(28.dp).testTag("map_refresh_live_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Sync Live Feeds",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Destination Input
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = destinationInput,
                            onValueChange = { destinationInput = it },
                            placeholder = { Text("Enter destination...", fontSize = 12.sp) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = null,
                                    tint = CautionOrange,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { calculateRoutesFor(destinationInput) }),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surface,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("map_destination_input")
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        Button(
                            onClick = { calculateRoutesFor(destinationInput) },
                            enabled = !isCalculatingRoute,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrandTeal),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("map_calculate_osrm_button")
                        ) {
                            if (isCalculatingRoute) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    strokeWidth = 2.dp,
                                    color = Color.White
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Directions,
                                    contentDescription = "Calculate OSRM Route",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Route", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Quick Destination Suggestions
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val quickDests = listOf("City Centre", "North Harbour", "Civic Hospital", "Industrial Ring")
                        items(quickDests) { dest ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (activeDestination == dest) BrandTeal.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (activeDestination == dest) BrandTeal else Color.Transparent
                                ),
                                modifier = Modifier
                                    .clickable {
                                        destinationInput = dest
                                        calculateRoutesFor(dest)
                                    }
                                    .testTag("quick_dest_$dest")
                            ) {
                                Text(
                                    text = dest,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (activeDestination == dest) BrandTeal else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }

                    // Route Comparison Banner (Fastest vs Safer)
                    val safestRoute = computedRoutes.maxByOrNull { it.safetyScore }
                    val fastestRoute = computedRoutes.minByOrNull { it.estimatedTimeMin }

                    if (safestRoute != null && fastestRoute != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                            modifier = Modifier.fillMaxWidth().testTag("route_comparison_summary")
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Safer Route Info
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Shield,
                                            contentDescription = null,
                                            tint = SafeGreen,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Column {
                                            Text("Safer: ${safestRoute.name.take(18)}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SafeGreen)
                                            Text("${safestRoute.distanceKm} km • ${safestRoute.estimatedTimeMin} min (Score ${safestRoute.safetyScore})", fontSize = 9.sp)
                                        }
                                    }

                                    // Fastest Route Info
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Bolt,
                                            contentDescription = null,
                                            tint = CautionOrange,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Column {
                                            Text("Fastest: ${fastestRoute.name.take(18)}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CautionOrange)
                                            Text("${fastestRoute.distanceKm} km • ${fastestRoute.estimatedTimeMin} min (Score ${fastestRoute.safetyScore})", fontSize = 9.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Filter Chips Carousel
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selectedFilterType == null) BrandTeal else MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                        modifier = Modifier
                            .clickable { selectedFilterType = null }
                            .testTag("filter_chip_all")
                    ) {
                        Text(
                            text = "All Hazards (${hazards.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (selectedFilterType == null) Color.White else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                items(HazardType.values().toList()) { type ->
                    val count = hazards.count { it.type == type }
                    if (count > 0) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selectedFilterType == type) BrandTeal else MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                            modifier = Modifier
                                .clickable { selectedFilterType = if (selectedFilterType == type) null else type }
                                .testTag("filter_chip_${type.name}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = type.getIcon(),
                                    contentDescription = null,
                                    tint = if (selectedFilterType == type) Color.White else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${type.displayName} ($count)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (selectedFilterType == type) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bottom Map Carousel (List of hazards to quick-tap)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp)
        ) {
            // Map Legend Pills
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(BrandSky)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("You: Metro Central", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(SafeGreen)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Safe Bypass: Route A", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Hazard preview cards carousel
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredHazards) { hazard ->
                    Card(
                        modifier = Modifier
                            .width(220.dp)
                            .clickable { selectedHazard = hazard }
                            .testTag("map_carousel_card_${hazard.id}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            hazard.riskLevel.color.copy(alpha = 0.6f)
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(hazard.riskLevel.color.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = hazard.type.getIcon(),
                                    contentDescription = null,
                                    tint = hazard.riskLevel.color,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = hazard.type.displayName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    maxLines = 1
                                )
                                Text(
                                    text = hazard.locationName,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${hazard.riskLevel.label} Risk • ${hazard.reportedTimeAgo}",
                                    fontSize = 9.sp,
                                    color = hazard.riskLevel.color,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Floating Action Button: Report Hazard
        FloatingActionButton(
            onClick = onReportHazard,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 85.dp, end = 16.dp)
                .testTag("fab_report_hazard"),
            containerColor = CautionOrange,
            contentColor = Color.Black
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Report Hazard",
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Report", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }

    // Detail Dialog
    HazardDetailDialog(
        hazard = selectedHazard,
        onDismiss = { selectedHazard = null },
        onNavigateAvoid = onNavigateSafeRoute
    )
}

/**
 * Normalized 2D screen positions (0.0 to 1.0) for live hazards and simulated positions.
 */
private fun getNormalizedCoordinates(hazard: Hazard): Pair<Float, Float> {
    if (hazard.latitude != 0.0 && hazard.longitude != 0.0 && (hazard.latitude < 37.7748 || hazard.latitude > 37.7752)) {
        // Dynamic geographic bounding projection
        val minLat = 37.73
        val maxLat = 37.82
        val minLon = -122.46
        val maxLon = -122.37
        val normX = ((hazard.longitude - minLon) / (maxLon - minLon)).toFloat().coerceIn(0.12f, 0.88f)
        val normY = (1f - ((hazard.latitude - minLat) / (maxLat - minLat)).toFloat()).coerceIn(0.12f, 0.88f)
        return Pair(normX, normY)
    }

    return when (hazard.id) {
        "haz-1" -> Pair(0.35f, 0.45f) // Main Road South (Flood)
        "haz-2" -> Pair(0.48f, 0.52f) // Central Area Blvd (Blockage)
        "haz-3" -> Pair(0.68f, 0.35f) // Highway Junction 4 (Accident)
        "haz-4" -> Pair(0.80f, 0.25f) // Industrial Park (Fire)
        "haz-5" -> Pair(0.38f, 0.28f) // North Ridge Scenic (Fallen Tree)
        "haz-6" -> Pair(0.58f, 0.18f) // West Harbour Bridge (Strong Wind)
        else -> {
            // Spread dynamically around the map grid
            val hash = hazard.id.hashCode()
            val rx = 0.25f + ((hash and 0x7FFF) % 50) / 100f
            val ry = 0.25f + (((hash shr 4) and 0x7FFF) % 50) / 100f
            Pair(rx, ry)
        }
    }
}
