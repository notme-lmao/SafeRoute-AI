package com.example.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.AlertsScreen
import com.example.ui.screens.AssistantScreen
import com.example.ui.screens.EmergencyHelpScreen
import com.example.ui.screens.HazardMapScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ReportHazardScreen
import com.example.ui.screens.RouteSearchScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.BrandTeal
import com.example.ui.theme.BrandTealLight

enum class NavTab(val title: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    MAP("Map", Icons.Default.Map),
    ALERTS("Alerts", Icons.Default.NotificationsActive),
    ASSISTANT("Assistant", Icons.Default.AutoAwesome)
}

enum class SubScreen {
    NONE,
    ROUTE_SEARCH,
    REPORT_HAZARD,
    EMERGENCY_HELP
}

/**
 * Main application coordinator holding top-level navigation, tab selection,
 * and modal/subscreen states.
 */
@Composable
fun MainAppContainer() {
    var showSplash by remember { mutableStateOf(true) }
    var currentTab by remember { mutableStateOf(NavTab.HOME) }
    var currentSubScreen by remember { mutableStateOf(SubScreen.NONE) }
    var activeDestination by remember { mutableStateOf("City Centre") }
    var assistantInitialQuery by remember { mutableStateOf<String?>(null) }

    if (showSplash) {
        SplashScreen(onContinue = { showSplash = false })
        return
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Only show bottom navigation when on primary tabs
            if (currentSubScreen == SubScreen.NONE) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    NavTab.values().forEach { tab ->
                        val isSelected = currentTab == tab
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentTab = tab },
                            icon = {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.title,
                                    tint = if (isSelected) BrandTealLight else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            label = {
                                Text(
                                    text = tab.title,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) BrandTealLight else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = BrandTeal.copy(alpha = 0.2f)
                            ),
                            modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentSubScreen) {
                SubScreen.ROUTE_SEARCH -> {
                    RouteSearchScreen(
                        initialDestination = activeDestination,
                        onBack = { currentSubScreen = SubScreen.NONE },
                        onViewOnMap = {
                            currentSubScreen = SubScreen.NONE
                            currentTab = NavTab.MAP
                        },
                        onAskAssistant = { query ->
                            assistantInitialQuery = query
                            currentSubScreen = SubScreen.NONE
                            currentTab = NavTab.ASSISTANT
                        }
                    )
                }
                SubScreen.REPORT_HAZARD -> {
                    ReportHazardScreen(
                        onBack = { currentSubScreen = SubScreen.NONE },
                        onReportSuccess = {
                            currentSubScreen = SubScreen.NONE
                            currentTab = NavTab.MAP
                        }
                    )
                }
                SubScreen.EMERGENCY_HELP -> {
                    EmergencyHelpScreen(
                        onBack = { currentSubScreen = SubScreen.NONE }
                    )
                }
                SubScreen.NONE -> {
                    Crossfade(targetState = currentTab, label = "tabCrossfade") { tab ->
                        when (tab) {
                            NavTab.HOME -> {
                                HomeScreen(
                                    onFindSafeRoute = { dest ->
                                        activeDestination = dest
                                        currentSubScreen = SubScreen.ROUTE_SEARCH
                                    },
                                    onViewHazardMap = { currentTab = NavTab.MAP },
                                    onOpenEmergencyHelp = { currentSubScreen = SubScreen.EMERGENCY_HELP },
                                    onOpenReportHazard = { currentSubScreen = SubScreen.REPORT_HAZARD },
                                    onOpenAlerts = { currentTab = NavTab.ALERTS }
                                )
                            }
                            NavTab.MAP -> {
                                HazardMapScreen(
                                    onReportHazard = { currentSubScreen = SubScreen.REPORT_HAZARD },
                                    onNavigateSafeRoute = {
                                        activeDestination = "City Centre"
                                        currentSubScreen = SubScreen.ROUTE_SEARCH
                                    }
                                )
                            }
                            NavTab.ALERTS -> {
                                AlertsScreen(
                                    onNavigateSafeBypass = {
                                        activeDestination = "City Centre"
                                        currentSubScreen = SubScreen.ROUTE_SEARCH
                                    }
                                )
                            }
                            NavTab.ASSISTANT -> {
                                AssistantScreen(
                                    initialPrompt = assistantInitialQuery,
                                    onNavigateRoutes = {
                                        activeDestination = "City Centre"
                                        currentSubScreen = SubScreen.ROUTE_SEARCH
                                    },
                                    onNavigateMap = { currentTab = NavTab.MAP }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
