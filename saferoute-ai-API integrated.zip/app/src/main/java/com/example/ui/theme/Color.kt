package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SafeRoute AI Emergency & Safety Design System
val SafeGreen = Color(0xFF10B981)
val SafeGreenDark = Color(0xFF047857)
val SafeGreenContainer = Color(0xFFD1FAE5)
val OnSafeGreenContainer = Color(0xFF064E3B)

val CautionOrange = Color(0xFFF59E0B)
val CautionOrangeDark = Color(0xFFB45309)
val CautionOrangeContainer = Color(0xFFFEF3C7)
val OnCautionOrangeContainer = Color(0xFF78350F)

val DangerRed = Color(0xFFEF4444)
val DangerRedDark = Color(0xFFB91C1C)
val DangerRedContainer = Color(0xFFFEE2E2)
val OnDangerRedContainer = Color(0xFF7F1D1D)

// Brand Accents
val BrandTeal = Color(0xFF0D9488)
val BrandTealLight = Color(0xFF14B8A6)
val BrandSky = Color(0xFF0284C7)
val BrandNavy = Color(0xFF0F172A)
val BrandNavyElevated = Color(0xFF1E293B)
val BrandNavyCard = Color(0xFF1E293B)

// Neutral Dark Canvas
val DarkBackground = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF131D33)
val DarkSurfaceElevated = Color(0xFF1C2A47)
val DarkSurfaceBorder = Color(0xFF2E3E63)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkTextTertiary = Color(0xFF64748B)

// Neutral Light Canvas (for light theme)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF1F5F9)
val LightSurfaceBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
