package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.DemoDataRepository
import com.example.model.DataSourceType
import com.example.model.Hazard
import com.example.model.LiveDataState
import com.example.model.RiskLevel
import com.example.model.RouteStatus
import com.example.ui.theme.CautionOrange
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.SafeGreen

/**
 * Score indicator pill showing 0-100 safety score with semantic color.
 */
@Composable
fun SafetyScoreBadge(
    score: Int,
    status: RouteStatus,
    modifier: Modifier = Modifier,
    showLabel: Boolean = true
) {
    val bgColor = when (status) {
        RouteStatus.SAFE -> SafeGreen.copy(alpha = 0.18f)
        RouteStatus.CAUTION -> CautionOrange.copy(alpha = 0.18f)
        RouteStatus.DANGER -> DangerRed.copy(alpha = 0.18f)
    }
    val textColor = when (status) {
        RouteStatus.SAFE -> SafeGreen
        RouteStatus.CAUTION -> CautionOrange
        RouteStatus.DANGER -> DangerRed
    }

    Surface(
        modifier = modifier.testTag("safety_score_badge"),
        shape = RoundedCornerShape(12.dp),
        color = bgColor,
        border = androidx.compose.foundation.BorderStroke(1.dp, textColor.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "$score/100",
                color = textColor,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            if (showLabel) {
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "• ${status.label}",
                    color = textColor,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp
                )
            }
        }
    }
}

/**
 * Hazard Information Dialog displayed when clicking a hazard marker or list item.
 */
@Composable
fun HazardDetailDialog(
    hazard: Hazard?,
    onDismiss: () -> Unit,
    onNavigateAvoid: (() -> Unit)? = null
) {
    if (hazard == null) return

    val riskColor = when (hazard.riskLevel) {
        RiskLevel.LOW -> SafeGreen
        RiskLevel.MEDIUM -> CautionOrange
        RiskLevel.HIGH, RiskLevel.CRITICAL -> DangerRed
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("hazard_detail_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, riskColor.copy(alpha = 0.6f))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(riskColor.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = hazard.type.getIcon(),
                                contentDescription = null,
                                tint = riskColor,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = riskColor.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "${hazard.riskLevel.label.uppercase()} RISK",
                                    color = riskColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = hazard.type.displayName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = hazard.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${hazard.locationName} (${hazard.roadName})",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Reported: ${hazard.reportedTimeAgo}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "FIELD DESCRIPTION",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = hazard.description,
                            style = MaterialTheme.typography.bodyMedium
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "ROAD IMPACT & ADVICE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = riskColor
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = hazard.impact,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("Close")
                    }
                    if (onNavigateAvoid != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                onNavigateAvoid()
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("Find Safe Bypass")
                        }
                    }
                }
            }
        }
    }
}

/**
 * Live Data Provenance & Synchronization Banner.
 * Displays real-time API status (Open-Meteo, NWS, Google Maps), timestamp of last sync,
 * active loading state, and fallback controls.
 */
@Composable
fun DemoModeBanner(
    modifier: Modifier = Modifier
) {
    val liveState by DemoDataRepository.liveDataState.collectAsState()
    var showDialog by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulseLive")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val isLive = liveState.sourceType == DataSourceType.LIVE_API
    val statusColor = if (isLive) SafeGreen else CautionOrange
    val borderColor = if (isLive) SafeGreen.copy(alpha = 0.35f) else CautionOrange.copy(alpha = 0.35f)
    val bgColor = if (isLive) SafeGreen.copy(alpha = 0.08f) else CautionOrange.copy(alpha = 0.08f)

    Column(modifier = modifier.fillMaxWidth()) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showDialog = true }
                .testTag("live_data_banner"),
            color = bgColor,
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, borderColor)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (liveState.isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(12.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(statusColor.copy(alpha = pulseAlpha))
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (isLive) "LIVE DISASTER DATA" else "FALLBACK SCENARIO",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = statusColor
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "• ${liveState.lastUpdatedTimestamp}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = if (liveState.isLoading) "Fetching live meteorological & traffic feeds..."
                            else "Source: ${liveState.sourceName}",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { DemoDataRepository.syncLiveData() },
                        modifier = Modifier.size(28.dp).testTag("sync_live_data_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh Live Feeds",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    IconButton(
                        onClick = { showDialog = true },
                        modifier = Modifier.size(28.dp).testTag("info_live_data_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Data Provenance Info",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // Optional Error or Notice Banner
        if (liveState.errorMessage != null && !isLive) {
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = CautionOrange.copy(alpha = 0.12f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = CautionOrange,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Notice: ${liveState.errorMessage}",
                        fontSize = 10.sp,
                        color = CautionOrange,
                        maxLines = 2
                    )
                }
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isLive) Icons.Default.CloudDone else Icons.Default.CloudOff,
                        contentDescription = null,
                        tint = statusColor,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Live Data & Telemetry Sources")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "SafeRoute AI connects to real-world APIs with an automatic offline safety fallback:",
                        style = MaterialTheme.typography.bodySmall
                    )

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "1. OpenStreetMap & Leaflet (Map Engine)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "• Status: Connected • Zero API key & Zero credit card required\n• Live interactive map tiles rendered via Leaflet frontend",
                                fontSize = 11.sp
                            )

                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "2. OSRM (Open Source Routing Machine)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "• Status: Connected • Real-time driving routes, distances & travel times\n• Evaluates & compares fastest corridor vs safer bypass",
                                fontSize = 11.sp
                            )

                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "3. Open-Meteo Weather API",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "• Status: Connected • No API key required\n• Real-time precipitation, wind gusts, weather codes\n• Current: ${liveState.liveWeatherSummary ?: "Synced"}",
                                fontSize = 11.sp
                            )

                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "4. National Weather Service (NWS) Alerts",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "• Status: Connected • Official flood warnings & civil defense bulletins",
                                fontSize = 11.sp
                            )
                        }
                    }

                    Text(
                        text = "Last Synced: ${liveState.lastUpdatedTimestamp}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        DemoDataRepository.syncLiveData()
                        showDialog = false
                    }
                ) {
                    Text("Sync Live APIs Now")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        DemoDataRepository.syncLiveData(forceFallback = !liveState.isMapsConfigured && isLive)
                        showDialog = false
                    }
                ) {
                    Text(if (isLive) "Test Fallback Mode" else "Reset to Defaults")
                }
            }
        )
    }
}

/**
 * Compact pill showing live data provenance and last updated time.
 */
@Composable
fun LiveDataStatusPill(
    modifier: Modifier = Modifier
) {
    val liveState by DemoDataRepository.liveDataState.collectAsState()
    val isLive = liveState.sourceType == DataSourceType.LIVE_API
    val statusColor = if (isLive) SafeGreen else CautionOrange

    Surface(
        modifier = modifier.testTag("live_data_status_pill"),
        color = statusColor.copy(alpha = 0.12f),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, statusColor.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(statusColor)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = if (isLive) "LIVE API" else "FALLBACK",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = statusColor
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "• ${liveState.lastUpdatedTimestamp}",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
