package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.logic.RouteManager
import com.example.logic.SafetyScoreCalculator
import com.example.model.RouteOption
import com.example.model.RouteStatus
import com.example.ui.components.LiveDataStatusPill
import com.example.ui.components.SafetyScoreBadge
import com.example.ui.theme.BrandTeal
import com.example.ui.theme.CautionOrange
import com.example.ui.theme.DangerRed
import com.example.ui.theme.SafeGreen
import kotlinx.coroutines.launch

/**
 * Route search and multi-route comparative safety evaluation screen.
 */
@Composable
fun RouteSearchScreen(
    initialDestination: String = "City Centre",
    onBack: () -> Unit,
    onViewOnMap: () -> Unit,
    onAskAssistant: (query: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var startLocation by remember { mutableStateOf("Current Location (Metro Central)") }
    var destination by remember { mutableStateOf(initialDestination.ifBlank { "City Centre" }) }
    var routes by remember { mutableStateOf(RouteManager.findSafeRoutes(startLocation, destination)) }
    var expandedRouteId by remember { mutableStateOf<String?>(routes.firstOrNull()?.id ?: "route-a") }
    var isCalculatingRoutes by remember { mutableStateOf(false) }

    fun refreshRoutes() {
        isCalculatingRoutes = true
        coroutineScope.launch {
            try {
                val computed = RouteManager.computeLiveSafeRoutes(startLocation, destination)
                routes = computed
                expandedRouteId = computed.firstOrNull { it.isRecommended }?.id ?: computed.firstOrNull()?.id
            } catch (e: Exception) {
                routes = RouteManager.findSafeRoutes(startLocation, destination)
            } finally {
                isCalculatingRoutes = false
            }
        }
    }

    LaunchedEffect(initialDestination) {
        if (initialDestination.isNotBlank() && initialDestination != "City Centre") {
            destination = initialDestination
            refreshRoutes()
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("route_search_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top App Bar with Live Data Provenance Indicator
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("route_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Home",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "Safe Route Comparison",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Evaluating real-time hazard proximity",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                LiveDataStatusPill()
            }
        }

        // Search Locations Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Start Location Input
                    OutlinedTextField(
                        value = startLocation,
                        onValueChange = { startLocation = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("start_location_input"),
                        label = { Text("From (Starting Location)") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.MyLocation,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Destination Input
                    OutlinedTextField(
                        value = destination,
                        onValueChange = { destination = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("destination_input"),
                        label = { Text("To (Destination)") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = DangerRed
                            )
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { refreshRoutes() },
                        enabled = !isCalculatingRoutes,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("recalculate_routes_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandTeal),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        if (isCalculatingRoutes) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Querying Live Routes & Hazards...", fontWeight = FontWeight.Bold)
                        } else {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Recalculate Safe Routes", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Fastest vs Safer Route Direct Comparison Card
        item {
            val safestRoute = routes.maxByOrNull { it.safetyScore }
            val fastestRoute = routes.minByOrNull { it.estimatedTimeMin }

            if (safestRoute != null && fastestRoute != null && safestRoute.id != fastestRoute.id) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("route_fastest_vs_safest_comparison_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CompareArrows,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Route Comparison: Fastest vs. Safer",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Safer Route Column
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                color = SafeGreen.copy(alpha = 0.15f),
                                border = androidx.compose.foundation.BorderStroke(1.5.dp, SafeGreen)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Shield, contentDescription = null, tint = SafeGreen, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Safer Corridor", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SafeGreen)
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(safestRoute.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                    Text("Score: ${safestRoute.safetyScore}/100", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = SafeGreen)
                                    Text("Time: ${safestRoute.estimatedTimeMin} mins", fontSize = 11.sp)
                                    Text("Dist: ${safestRoute.distanceKm} km", fontSize = 11.sp)
                                    Text("Hazards: ${safestRoute.hazardsEncountered.size} avoided", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            // Fastest Route Column
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                color = CautionOrange.copy(alpha = 0.15f),
                                border = androidx.compose.foundation.BorderStroke(1.5.dp, CautionOrange)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Bolt, contentDescription = null, tint = CautionOrange, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Fastest Path", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CautionOrange)
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(fastestRoute.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                    Text("Score: ${fastestRoute.safetyScore}/100", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = fastestRoute.status.color)
                                    Text("Time: ${fastestRoute.estimatedTimeMin} mins", fontSize = 11.sp)
                                    Text("Dist: ${fastestRoute.distanceKm} km", fontSize = 11.sp)
                                    Text("Hazards: ${fastestRoute.hazardsEncountered.size} nearby", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        val timeDiff = safestRoute.estimatedTimeMin - fastestRoute.estimatedTimeMin
                        val scoreDiff = safestRoute.safetyScore - fastestRoute.safetyScore

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (timeDiff > 0) {
                                "💡 Trade-off: Taking the safer corridor adds +${timeDiff} min but gives +${scoreDiff} higher safety score, bypassing active hazard zones."
                            } else {
                                "💡 Safe & Optimal: The safest route is also the fastest corridor available!"
                            },
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Recommendation Banner
        item {
            val recommendedRoute = routes.firstOrNull { it.isRecommended } ?: routes.firstOrNull()
            if (recommendedRoute != null) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = SafeGreen.copy(alpha = 0.14f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SafeGreen.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(SafeGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "RECOMMENDED: ${recommendedRoute.name}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SafeGreen
                            )
                            Text(
                                text = recommendedRoute.explanation,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // Available Routes Header
        item {
            Text(
                text = "Route Analysis (${routes.size} corridors found)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        // Route Cards List
        items(routes) { route ->
            val isExpanded = expandedRouteId == route.id
            val statusBorderColor = when (route.status) {
                RouteStatus.SAFE -> SafeGreen
                RouteStatus.CAUTION -> CautionOrange
                RouteStatus.DANGER -> DangerRed
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        expandedRouteId = if (isExpanded) null else route.id
                    }
                    .testTag("route_card_${route.id}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (route.isRecommended) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                ),
                border = androidx.compose.foundation.BorderStroke(
                    width = if (route.isRecommended) 2.dp else 1.dp,
                    color = if (route.isRecommended) SafeGreen else statusBorderColor.copy(alpha = 0.4f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Title and Badges
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            if (route.isRecommended) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = SafeGreen,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                ) {
                                    Text(
                                        text = "★ SAFEST RECOMMENDED",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            } else if (route.isFastest) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = CautionOrange,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                ) {
                                    Text(
                                        text = "⚡ FASTEST TRAVEL TIME (${route.estimatedTimeMin} min)",
                                        color = Color.Black,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                            Text(
                                text = route.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = route.viaRoads,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        SafetyScoreBadge(
                            score = route.safetyScore,
                            status = route.status
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Metrics Row (Distance, Time, Status)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "DISTANCE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${route.distanceKm} km",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        Column {
                            Text(
                                text = "EST. TIME",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${route.estimatedTimeMin} min",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        Column {
                            Text(
                                text = "STATUS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = route.status.label,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = statusBorderColor
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Hazard Explanation
                    Row(
                        verticalAlignment = Alignment.Top,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = if (route.status == RouteStatus.SAFE) Icons.Default.Shield else Icons.Default.Warning,
                            contentDescription = null,
                            tint = statusBorderColor,
                            modifier = Modifier
                                .size(18.dp)
                                .padding(top = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = route.explanation,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (route.status == RouteStatus.SAFE) MaterialTheme.colorScheme.onSurface else statusBorderColor
                        )
                    }

                    // Expandable Checkpoints
                    AnimatedVisibility(visible = isExpanded) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            Text(
                                text = "Navigation Checkpoints:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            route.checkpoints.forEachIndexed { index, step ->
                                Row(
                                    modifier = Modifier.padding(vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${index + 1}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = step,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = onViewOnMap,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Map,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("View on Map", fontSize = 12.sp)
                                }

                                OutlinedButton(
                                    onClick = {
                                        onAskAssistant("Why is ${route.name.take(7)} risky?")
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Chat,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Ask AI", fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // Toggle expand chevron
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isExpanded) "Hide details" else "Tap for turn-by-turn & actions",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // Disclaimer Note
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = SafetyScoreCalculator.DISCLAIMER,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 15.sp
                    )
                }
            }
        }
    }
}
