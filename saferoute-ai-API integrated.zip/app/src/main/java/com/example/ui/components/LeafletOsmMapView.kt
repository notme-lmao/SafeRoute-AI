package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.Hazard
import com.example.model.HazardType
import com.example.model.RiskLevel
import org.json.JSONArray
import org.json.JSONObject

/**
 * Native Android Jetpack Compose Leaflet & OpenStreetMap view.
 * 100% Free and open-source map engine requiring zero API keys and zero credit card.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LeafletOsmMapView(
    hazards: List<Hazard>,
    selectedHazard: Hazard? = null,
    userLocation: Pair<Double, Double> = Pair(37.7749, -122.4194),
    destinationLocation: Pair<Double, Double>? = Pair(37.7850, -122.4080),
    destinationName: String = "City Centre",
    routeCoordinates: List<Pair<Double, Double>> = emptyList(),
    onHazardSelected: (Hazard) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val webView = remember {
        WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                loadWithOverviewMode = true
                useWideViewPort = true
                cacheMode = WebSettings.LOAD_DEFAULT
            }
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {}
        }
    }

    // Set up JavaScript bridge to handle hazard marker clicks
    val jsBridge = remember {
        object {
            @JavascriptInterface
            fun onHazardClicked(hazardId: String) {
                Handler(Looper.getMainLooper()).post {
                    val clicked = hazards.find { it.id == hazardId }
                    if (clicked != null) {
                        onHazardSelected(clicked)
                    }
                }
            }
        }
    }

    LaunchedEffect(webView) {
        webView.addJavascriptInterface(jsBridge, "SafeRouteBridge")
        val initialHtml = generateLeafletHtml(
            hazards = hazards,
            userLocation = userLocation,
            destinationLocation = destinationLocation,
            destinationName = destinationName,
            routeCoordinates = routeCoordinates
        )
        webView.loadDataWithBaseURL("https://openstreetmap.org", initialHtml, "text/html", "UTF-8", null)
    }

    // Update markers and route polyline when state changes
    LaunchedEffect(hazards, userLocation, destinationLocation, routeCoordinates, destinationName) {
        val updateScript = generateUpdateScript(
            hazards = hazards,
            userLocation = userLocation,
            destinationLocation = destinationLocation,
            destinationName = destinationName,
            routeCoordinates = routeCoordinates
        )
        webView.evaluateJavascript(updateScript, null)
    }

    Box(modifier = modifier.fillMaxSize()) {
        AndroidView(
            factory = { webView },
            modifier = Modifier.fillMaxSize()
        )
    }
}

/**
 * Generates the self-contained HTML page embedding Leaflet 1.9.4 and OpenStreetMap.
 */
private fun generateLeafletHtml(
    hazards: List<Hazard>,
    userLocation: Pair<Double, Double>,
    destinationLocation: Pair<Double, Double>?,
    destinationName: String,
    routeCoordinates: List<Pair<Double, Double>>
): String {
    val hazardsJson = hazardsToJson(hazards)
    val routeJson = routeToJson(routeCoordinates)
    val destLat = destinationLocation?.first ?: 37.7850
    val destLon = destinationLocation?.second ?: -122.4080

    return """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
    <style>
        html, body, #map {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            background-color: #0f172a;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
        .leaflet-tile {
            filter: brightness(0.88) contrast(1.1) saturate(0.9);
        }
        .user-pulse {
            width: 18px;
            height: 18px;
            background: #0284c7;
            border: 2px solid #ffffff;
            border-radius: 50%;
            box-shadow: 0 0 12px #0284c7;
        }
        .dest-marker {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            background: #eab308;
            border: 2px solid #ffffff;
            border-radius: 50%;
            color: #000;
            font-weight: bold;
            font-size: 16px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.5);
        }
        .hazard-pin {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            color: #ffffff;
            font-size: 16px;
            border: 2px solid #ffffff;
            box-shadow: 0 3px 8px rgba(0,0,0,0.4);
            cursor: pointer;
        }
        .hazard-critical { background: #ef4444; }
        .hazard-high { background: #dc2626; }
        .hazard-medium { background: #f59e0b; }
        .hazard-low { background: #10b981; }
        .leaflet-popup-content-wrapper {
            background: #1e293b;
            color: #f8fafc;
            border-radius: 12px;
            border: 1px solid #334155;
            box-shadow: 0 10px 25px rgba(0,0,0,0.5);
        }
        .leaflet-popup-tip {
            background: #1e293b;
        }
        .popup-title {
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 4px;
        }
        .popup-badge {
            display: inline-block;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 6px;
        }
        .badge-critical { background: rgba(239,68,68,0.25); color: #f87171; border: 1px solid #ef4444; }
        .badge-high { background: rgba(220,38,38,0.25); color: #f87171; border: 1px solid #dc2626; }
        .badge-medium { background: rgba(245,158,11,0.25); color: #fbbf24; border: 1px solid #f59e0b; }
        .badge-low { background: rgba(16,185,129,0.25); color: #34d399; border: 1px solid #10b981; }
        .popup-desc {
            font-size: 12px;
            color: #cbd5e1;
            margin-bottom: 6px;
        }
        .popup-impact {
            font-size: 11px;
            color: #f87171;
            background: rgba(239,68,68,0.1);
            padding: 6px;
            border-radius: 6px;
        }
    </style>
</head>
<body>
    <div id="map"></div>
    <script>
        var map = L.map('map', {
            zoomControl: false,
            attributionControl: false
        }).setView([${userLocation.first}, ${userLocation.second}], 14);

        L.control.zoom({ position: 'bottomright' }).addTo(map);

        // OpenStreetMap Free Tile Layer
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19
        }).addTo(map);

        var hazardLayer = L.layerGroup().addTo(map);
        var routeLayer = L.layerGroup().addTo(map);
        var userMarker = null;
        var destMarker = null;

        function updateUserLocation(lat, lon) {
            if (userMarker) map.removeLayer(userMarker);
            var icon = L.divIcon({
                className: 'user-pulse',
                iconSize: [18, 18],
                iconAnchor: [9, 9]
            });
            userMarker = L.marker([lat, lon], { icon: icon })
                .bindPopup('<b style="color:#0284c7">Your Location</b><br>Metro Central')
                .addTo(map);
        }

        function updateDestination(lat, lon, name) {
            if (destMarker) map.removeLayer(destMarker);
            var icon = L.divIcon({
                className: 'dest-marker',
                html: '📍',
                iconSize: [32, 32],
                iconAnchor: [16, 16]
            });
            destMarker = L.marker([lat, lon], { icon: icon })
                .bindPopup('<b>Destination</b><br>' + name)
                .addTo(map);
        }

        function updateHazards(hazardsList) {
            hazardLayer.clearLayers();
            hazardsList.forEach(function(h) {
                var cls = 'hazard-medium';
                var badgeCls = 'badge-medium';
                if (h.risk === 'CRITICAL') { cls = 'hazard-critical'; badgeCls = 'badge-critical'; }
                else if (h.risk === 'HIGH') { cls = 'hazard-high'; badgeCls = 'badge-high'; }
                else if (h.risk === 'LOW') { cls = 'hazard-low'; badgeCls = 'badge-low'; }

                var icon = L.divIcon({
                    className: 'hazard-pin ' + cls,
                    html: h.emoji,
                    iconSize: [32, 32],
                    iconAnchor: [16, 16]
                });

                var popupHtml = '<div class="popup-title">' + h.title + '</div>' +
                    '<span class="popup-badge ' + badgeCls + '">' + h.risk + ' RISK • ' + h.type + '</span>' +
                    '<div class="popup-desc">' + h.description + '</div>' +
                    '<div class="popup-impact">⚠️ ' + h.impact + '</div>';

                var marker = L.marker([h.lat, h.lon], { icon: icon })
                    .bindPopup(popupHtml);

                marker.on('click', function() {
                    if (window.SafeRouteBridge && window.SafeRouteBridge.onHazardClicked) {
                        window.SafeRouteBridge.onHazardClicked(h.id);
                    }
                });

                hazardLayer.addLayer(marker);
            });
        }

        function updateRoute(coordinates) {
            routeLayer.clearLayers();
            if (coordinates && coordinates.length > 1) {
                var polyline = L.polyline(coordinates, {
                    color: '#10b981',
                    weight: 6,
                    opacity: 0.85,
                    lineJoin: 'round'
                });
                routeLayer.addLayer(polyline);
                map.fitBounds(polyline.getBounds(), { padding: [40, 40] });
            }
        }

        // Initialize state
        updateUserLocation(${userLocation.first}, ${userLocation.second});
        updateDestination($destLat, $destLon, "$destinationName");
        updateHazards($hazardsJson);
        updateRoute($routeJson);
    </script>
</body>
</html>
    """.trimIndent()
}

private fun generateUpdateScript(
    hazards: List<Hazard>,
    userLocation: Pair<Double, Double>,
    destinationLocation: Pair<Double, Double>?,
    destinationName: String,
    routeCoordinates: List<Pair<Double, Double>>
): String {
    val hazardsJson = hazardsToJson(hazards)
    val routeJson = routeToJson(routeCoordinates)
    val destLat = destinationLocation?.first ?: 37.7850
    val destLon = destinationLocation?.second ?: -122.4080

    return """
        if (typeof updateHazards === 'function') {
            updateUserLocation(${userLocation.first}, ${userLocation.second});
            updateDestination($destLat, $destLon, "$destinationName");
            updateHazards($hazardsJson);
            updateRoute($routeJson);
        }
    """.trimIndent()
}

private fun hazardsToJson(hazards: List<Hazard>): String {
    val array = JSONArray()
    for (h in hazards) {
        val obj = JSONObject()
        obj.put("id", h.id)
        obj.put("title", h.title)
        obj.put("type", h.type.displayName)
        obj.put("risk", h.riskLevel.name)
        obj.put("description", h.description)
        obj.put("impact", h.impact)
        obj.put("lat", h.latitude)
        obj.put("lon", h.longitude)
        obj.put("emoji", getHazardEmoji(h.type))
        array.put(obj)
    }
    return array.toString()
}

private fun routeToJson(coords: List<Pair<Double, Double>>): String {
    val array = JSONArray()
    for (pt in coords) {
        val ptArr = JSONArray()
        ptArr.put(pt.first)
        ptArr.put(pt.second)
        array.put(ptArr)
    }
    return array.toString()
}

private fun getHazardEmoji(type: HazardType): String {
    return when (type) {
        HazardType.FLOOD -> "🌊"
        HazardType.FIRE -> "🔥"
        HazardType.ACCIDENT -> "🚗"
        HazardType.ROAD_BLOCKAGE -> "🚧"
        HazardType.FALLEN_TREE -> "🌲"
        HazardType.STRONG_WIND -> "💨"
        HazardType.OTHER -> "⚠️"
    }
}
