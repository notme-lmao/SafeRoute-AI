package com.example.logic

import com.example.data.DemoDataRepository
import com.example.model.ChatMessage
import com.example.model.HazardType
import com.example.model.MessageSender
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Grounded rule-based intelligence engine for "SafeRoute Assistant".
 * Provides precise safety guidance using actual application data (hazards, routes, shelters)
 * without hallucinating unverified disaster events.
 */
object AssistantEngine {

    val defaultSuggestedPrompts = listOf(
        "Is it safe to travel to the city centre?",
        "Which route is safer?",
        "Why is Route B risky?",
        "Are there any hazards near me?",
        "What should I do if I encounter flooding?"
    )

    fun getInitialGreeting(): ChatMessage {
        return ChatMessage(
            id = "welcome-msg",
            sender = MessageSender.ASSISTANT,
            text = "Hello! I am your SafeRoute Assistant. I monitor active hazards, evaluate route risks, and provide emergency travel advice based on current field reports.\n\nHow can I help you stay safe today?",
            timestamp = currentTimeString(),
            suggestedPrompts = defaultSuggestedPrompts
        )
    }

    /**
     * Generates a grounded response based on the user question and real app data.
     */
    fun processQuery(query: String): ChatMessage {
        val q = query.trim().lowercase(Locale.ROOT)
        val hazards = DemoDataRepository.hazards.value
        val routes = RouteManager.findSafeRoutes()
        val routeA = routes.firstOrNull { it.id == "route-a" }
        val routeB = routes.firstOrNull { it.id == "route-b" }
        val routeC = routes.firstOrNull { it.id == "route-c" }

        val responseText: String
        val followUps: MutableList<String> = mutableListOf()

        when {
            // "Why is Route B risky?"
            q.contains("route b") || (q.contains("risky") && q.contains("b")) -> {
                val flood = hazards.firstOrNull { it.type == HazardType.FLOOD }
                val desc = flood?.description ?: "Flooding reported 500 m ahead on Main Road."
                responseText = "Route B is rated CAUTION (Safety Score: ${routeB?.safetyScore ?: 52}/100) because $desc Water levels reach up to 45 cm, creating significant danger of vehicle stalling and hydroplaning.\n\nRecommended: Use Route A instead via the elevated viaduct."
                followUps.add("Which route is safer?")
                followUps.add("What should I do if I encounter flooding?")
            }

            // "Which route is safer?"
            q.contains("which route") || q.contains("safer route") || q.contains("recommend") -> {
                responseText = "Route A (${routeA?.name ?: "Riverbank Bypass"}) is currently the safest option with a Safety Score of ${routeA?.safetyScore ?: 88}/100 (Status: SAFE).\n\n• Route A: 6.2 km (18 min) - High-ground viaduct, zero flood crossings.\n• Route B: 5.4 km (15 min) - High risk flooding on Main Road.\n• Route C: 7.1 km (25 min) - Severe chemical fire exclusion zone.\n\nWe recommend Route A for your journey."
                followUps.add("Why is Route B risky?")
                followUps.add("Are there any hazards near me?")
            }

            // "Is it safe to travel to the city centre?" / destination safety
            q.contains("city centre") || q.contains("safe to travel") || q.contains("safe to go") -> {
                responseText = "Route A is currently the safer option. Route B has reported road blockage and severe waterlogging on Main Road. Consider using Route A via the Riverbank Elevated Bypass for a secure transit to the city centre."
                followUps.add("Which route is safer?")
                followUps.add("Why is Route B risky?")
            }

            // "Are there any hazards near me?"
            q.contains("hazards near me") || q.contains("any hazards") || q.contains("nearby hazards") -> {
                val count = hazards.size
                val listSummary = hazards.take(3).joinToString("\n") { "• ${it.title} at ${it.locationName} (${it.riskLevel.label} Risk)" }
                responseText = "There are currently $count active hazards reported in the region. The closest ones to your location are:\n\n$listSummary\n\nCheck the Hazard Map tab for real-time visual perimeter overlays."
                followUps.add("Which route is safer?")
                followUps.add("Is it safe to travel to the city centre?")
            }

            // "What should I do if I encounter flooding?"
            q.contains("flooding") || q.contains("water") || q.contains("flood") -> {
                responseText = "FLOOD SAFETY RULES (Turn Around, Don't Drown):\n\n1. Never drive into water covering the road. As little as 6 inches (15 cm) of moving water can knock you down, and 12 inches (30 cm) can float most vehicles.\n2. If your vehicle stalls in rising water, abandon it immediately and seek higher ground.\n3. Do not walk through moving water.\n4. Avoid downed power lines touching pooled water.\n5. Stay tuned to SafeRoute AI alerts for open bypass roads."
                followUps.add("Where is the nearest shelter?")
                followUps.add("Call emergency services")
            }

            // Hospital inquiries
            q.contains("hospital") || q.contains("medical") || q.contains("doctor") || q.contains("injured") -> {
                val hosp = DemoDataRepository.facilities.value.firstOrNull { it.type == com.example.model.FacilityType.HOSPITAL }
                responseText = if (hosp != null) {
                    "Nearest Emergency Medical Center:\n• ${hosp.name}\n• Address: ${hosp.address} (${hosp.distanceKm} km away)\n• Contact: ${hosp.contactNumber}\n• Status: ${hosp.statusInfo}\n\nGo to the Emergency Help screen to initiate a one-tap call or GPS directions."
                } else {
                    "City General Trauma Center is 1.8 km away. Call 911 or 112 immediately for emergency triage."
                }
                followUps.add("Where is the nearest shelter?")
            }

            // Shelter inquiries
            q.contains("shelter") || q.contains("evacuate") || q.contains("evacuation") -> {
                val shelter = DemoDataRepository.facilities.value.firstOrNull { it.type == com.example.model.FacilityType.SHELTER }
                responseText = if (shelter != null) {
                    "Nearest Emergency Relief Shelter:\n• ${shelter.name}\n• Address: ${shelter.address} (${shelter.distanceKm} km away)\n• Capacity: ${shelter.capacityInfo}\n• Status: ${shelter.statusInfo}\n\nSupplies, warm beds, and food are available."
                } else {
                    "North Community Civic Center (2.4 km away) is designated as an active emergency relief shelter."
                }
                followUps.add("Is it safe to travel to the city centre?")
            }

            // Safety score explanation
            q.contains("score") || q.contains("how is safety calculated") || q.contains("algorithm") -> {
                responseText = "SafeRoute AI calculates Safety Scores (0–100) using multi-factor hazard deduction:\n• 90–100 (SAFE): Zero hazards along route.\n• 70–89 (SAFE): Minor or distant weather advisories.\n• 40–69 (CAUTION): Medium risk (partial road block, water accumulation).\n• 0–39 (DANGER): High-risk hazards (active flood, chemical fire, fallen high-voltage cables).\n\nScores update automatically as citizens and authorities submit incident reports."
                followUps.add("Which route is safer?")
            }

            // Emergency call
            q.contains("emergency") || q.contains("call") || q.contains("help") || q.contains("police") -> {
                responseText = "For immediate life-threatening situations, dial Emergency Services immediately (112 or 911). Tap the 'Emergency Help' button on the Home tab for 1-tap SOS calls and coordinate sharing."
                followUps.add("Where is the nearest hospital?")
            }

            // General / Fallback
            else -> {
                responseText = "I can analyze route safety, hazard risks, and nearby emergency shelters. Based on current local disaster data:\n• Route A is recommended (88/100 Safe).\n• Route B has active flooding on Main Road.\n\nSelect a question below or ask about routes, flooding, or shelters."
                followUps.addAll(defaultSuggestedPrompts.take(3))
            }
        }

        return ChatMessage(
            id = "bot-${UUID.randomUUID().toString().take(6)}",
            sender = MessageSender.ASSISTANT,
            text = responseText,
            timestamp = currentTimeString(),
            suggestedPrompts = followUps
        )
    }

    private fun currentTimeString(): String {
        val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
        return sdf.format(Date())
    }
}
