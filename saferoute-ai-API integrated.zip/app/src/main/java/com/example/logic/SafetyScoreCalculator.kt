package com.example.logic

import com.example.model.CurrentWeatherInfo
import com.example.model.Hazard
import com.example.model.RiskLevel
import com.example.model.RouteStatus

/**
 * Calculates a 0-100 safety score for routes based on nearby hazards,
 * road obstructions, severity levels, and Open-Meteo real-time weather telemetry.
 */
object SafetyScoreCalculator {

    const val DISCLAIMER =
        "Prototype Safety Score: Calculated from local hazard reports, terrain safety factors, and Open-Meteo live weather telemetry. This is an informational prototype and not an official civil defense evacuation order."

    /**
     * Calculates safety score and status based on hazards encountered along a route
     * and Open-Meteo live weather conditions.
     *
     * Rules:
     * - No hazards & fair weather: 90 - 100 (SAFE)
     * - Low-risk hazards / light rain: 70 - 89 (SAFE)
     * - Medium-risk hazards / heavy precipitation / strong winds: 40 - 69 (CAUTION)
     * - High-risk/Critical hazards or severe storm cells: 0 - 39 (DANGER)
     */
    fun calculateScore(
        hazards: List<Hazard>,
        weather: CurrentWeatherInfo? = null
    ): Pair<Int, RouteStatus> {
        var totalDeduction = 0
        var hasCritical = false
        var hasHigh = false
        var hasMedium = false

        for (hazard in hazards) {
            when (hazard.riskLevel) {
                RiskLevel.CRITICAL -> {
                    totalDeduction += 55
                    hasCritical = true
                }
                RiskLevel.HIGH -> {
                    totalDeduction += 40
                    hasHigh = true
                }
                RiskLevel.MEDIUM -> {
                    totalDeduction += 22
                    hasMedium = true
                }
                RiskLevel.LOW -> {
                    totalDeduction += 10
                }
            }
        }

        // Incorporate real-time weather factor from Open-Meteo
        if (weather != null) {
            totalDeduction += weather.weatherRiskDeduction
            if (weather.weatherRiskDeduction >= 25) {
                hasHigh = true
            } else if (weather.weatherRiskDeduction >= 15) {
                hasMedium = true
            }
        }

        if (hazards.isEmpty() && (weather == null || weather.weatherRiskDeduction == 0)) {
            return Pair(94, RouteStatus.SAFE)
        }

        val rawScore = (100 - totalDeduction).coerceIn(12, 100)

        val status = when {
            hasCritical || rawScore < 40 -> RouteStatus.DANGER
            hasHigh || rawScore in 40..69 -> RouteStatus.CAUTION
            else -> RouteStatus.SAFE
        }

        return Pair(rawScore, status)
    }

    /**
     * Formats status label and explanation for why a route has caution or danger.
     */
    fun getScoreRationale(
        score: Int,
        status: RouteStatus,
        hazards: List<Hazard>,
        weather: CurrentWeatherInfo? = null
    ): String {
        val weatherNote = if (weather != null && weather.weatherRiskDeduction > 0) {
            " [Weather: ${weather.conditionDescription}, ${weather.windSpeedKmh.toInt()} km/h wind]"
        } else ""

        return when (status) {
            RouteStatus.SAFE -> {
                if (hazards.isEmpty()) {
                    "No reported floodwaters, roadblocks, or fire hazards detected along this corridor.$weatherNote"
                } else {
                    "Minor weather advisories detected nearby, but road surface remains fully passable.$weatherNote"
                }
            }
            RouteStatus.CAUTION -> {
                val primary = hazards.firstOrNull()?.description ?: "Partial obstruction reported."
                "Caution: $primary$weatherNote Proceed at reduced speed or select safer recommended bypass."
            }
            RouteStatus.DANGER -> {
                val primary = hazards.firstOrNull()?.description ?: "Severe hazard zone."
                "Danger: $primary$weatherNote Extreme risk of vehicle entrapment. Avoid this corridor."
            }
        }
    }
}

