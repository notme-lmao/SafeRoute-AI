package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.DemoDataRepository
import com.example.logic.AssistantEngine
import com.example.logic.RouteManager
import com.example.logic.SafetyScoreCalculator
import com.example.model.HazardType
import com.example.model.RiskLevel
import com.example.model.RouteStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Before
  fun setup() {
    DemoDataRepository.resetToDefaults()
  }

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("SafeRoute AI", appName)
  }

  @Test
  fun `safety score calculator evaluates clean and hazardous routes correctly`() {
    val cleanResult = SafetyScoreCalculator.calculateScore(emptyList())
    assertEquals(94, cleanResult.first)
    assertEquals(RouteStatus.SAFE, cleanResult.second)

    val hazards = DemoDataRepository.hazards.value
    val (hazardsScore, hazardsStatus) = SafetyScoreCalculator.calculateScore(hazards)
    assertTrue("Score should decrease with hazards present", hazardsScore < 60)
  }

  @Test
  fun `route manager recommends Route A as the safest route`() {
    val routes = RouteManager.findSafeRoutes("Metro Central", "City Centre")
    assertTrue("Should generate at least 2 routes", routes.size >= 2)

    val recommended = routes.find { it.isRecommended }
    assertNotNull("A recommended route must exist", recommended)
    assertEquals("Route A (Recommended)", recommended?.name)
    assertEquals(RouteStatus.SAFE, recommended?.status)
    assertTrue("Recommended route must have high safety score", (recommended?.safetyScore ?: 0) >= 80)
  }

  @Test
  fun `assistant engine returns grounded answers for common queries`() {
    val safeQueryReply = AssistantEngine.processQuery("Is it safe to travel to the city centre?")
    assertTrue(safeQueryReply.text.contains("Route A"))

    val riskQueryReply = AssistantEngine.processQuery("Why is Route B risky?")
    assertTrue(riskQueryReply.text.contains("flooding", ignoreCase = true) || riskQueryReply.text.contains("blockage", ignoreCase = true))

    val floodQueryReply = AssistantEngine.processQuery("What should I do if I encounter flooding?")
    assertTrue(floodQueryReply.text.contains("Turn Around Don't Drown", ignoreCase = true) || floodQueryReply.text.contains("flood", ignoreCase = true))
  }

  @Test
  fun `reporting new hazard updates repository correctly`() {
    val initialCount = DemoDataRepository.hazards.value.size
    DemoDataRepository.reportHazard(
      type = HazardType.ROAD_BLOCKAGE,
      locationName = "North Crossing",
      description = "Fallen sign blocking both lanes",
      riskLevel = RiskLevel.HIGH
    )

    val updatedHazards = DemoDataRepository.hazards.value
    assertEquals(initialCount + 1, updatedHazards.size)
    val latest = updatedHazards.first()
    assertEquals("North Crossing", latest.locationName)
    assertEquals(HazardType.ROAD_BLOCKAGE, latest.type)
  }
}

