# SafeRoute AI
> **"Don't just find a route. Find a safer route."**

SafeRoute AI is an emergency and disaster-management Android navigation application built for a college hackathon. While standard navigation systems prioritize the fastest or shortest path, SafeRoute AI evaluates life-safety factors such as active floodwaters, road debris, chemical fires, storm damage, and fallen electrical lines to compute and recommend the safest navigational corridor.

---

## 1. Problem Statement
During severe weather events, floods, and natural disasters, conventional GPS routing often leads citizens and emergency vehicles straight into impassable underpasses, flooded avenues, and hazardous choke-points. Evacuees need clear visibility of danger zones, real-time safety scores, civil emergency broadcasts, and immediate access to shelters and hospitals.

## 2. Solution
SafeRoute AI introduces **Hazard-Aware Navigation**:
- Computes dynamic **0–100 Safety Scores** based on proximity to active incidents.
- Highlights clear **Safe Bypasses** (e.g., elevated viaducts) while flagging obstructed paths with actionable warnings (e.g., *"Flooding reported 500 m ahead"*).
- Displays an interactive **Hazard Map** with live danger radiuses and incident cards.
- Provides a grounded, rule-based **SafeRoute Assistant** AI that answers route-specific questions without hallucinating fictitious emergency data.
- Includes 1-tap **Emergency Help** with rapid dialer intents, nearby shelter directory, and coordinate check-in sharing.

---

## 3. Key Features

1. **Splash & Onboarding Screen**
   - Welcomes users with the project identity, tagline, and instant launch button.

2. **Emergency Management Dashboard (Home Screen)**
   - Displays current regional safety status (e.g., *"Moderate Risk • 2 hazards nearby"*).
   - Shows current user coordinates (Metro Central).
   - "Where do you want to go?" search box with quick destination chips (*City Centre, Hospital, Shelter, Airport*).
   - Direct launch actions: *Find Safe Route*, *Hazard Map*, *SOS Emergency Help*, and *Report Hazard*.
   - Live broadcast alerts feed.

3. **Multi-Route Comparative Safety Evaluation**
   - Compares 3 distinct routes simultaneously:
     - **Route A (Riverbank Elevated Bypass)**: Safety Score **88/100 (SAFE)** • Recommended Route.
     - **Route B (Main Road Direct)**: Safety Score **52/100 (CAUTION)** • Flooding reported 500 m ahead.
     - **Route C (Industrial Arterial)**: Safety Score **28/100 (DANGER)** • Chemical fire perimeter & roadblock.
   - Explains the exact reason for lower scores and displays step-by-step navigation checkpoints.

4. **Interactive Hazard Map**
   - High-performance custom canvas vector map depicting roads, waterways, districts, user beacon, and destination pin.
   - Color-coded hazard markers with pulsing radar risk circles:
     - **Water Drop**: Flash floods & waterlogging
     - **Flame**: Industrial fires
     - **Car Crash**: Multi-vehicle accidents
     - **Barrier**: Scaffolding & road blockages
     - **Tree**: Downed trees and power lines
     - **Wind**: Gale force gusts
   - Tapping any hazard pin displays its official incident detail card (risk level, report time, description, road impact).
   - Filter chips to view specific hazard categories.

5. **Citizen Hazard Reporting**
   - Form allowing evacuees to report incidents in the field.
   - Select hazard type, risk level (Low to Critical), location, and field notes.
   - Instantly persists the report locally and updates the map, alerts, route calculations, and AI assistant dynamically.

6. **Emergency Alerts Center**
   - Categorized broadcast bulletin:
     - **RED ALERT**: Complete road blockage on Main Road.
     - **ORANGE ALERT**: Heavy flooding in Central Basin underpass.
     - **YELLOW ALERT**: Severe gale winds in northern sector.
   - Direct SMS/Social sharing intent and "Find Safe Bypass" button.

7. **Emergency Help & SOS Center**
   - **Call Emergency Services**: 1-tap dialer intent (`112` / `911`).
   - **Find Nearby Hospital**: Directory of emergency ERs with distance, bed status, and 1-tap calling.
   - **Find Emergency Shelter**: Directory of open relief centres with bed capacity and supplies status.
   - **Share Location**: Instant check-in message with coordinates.
   - **Rescue Beacon**: Visual high-contrast screen strobe for emergency search and rescue teams.

8. **SafeRoute Assistant (Rule-Based AI Chat)**
   - Pre-loaded quick prompt chips:
     - *"Is it safe to travel to the city centre?"*
     - *"Which route is safer?"*
     - *"Why is Route B risky?"*
     - *"Are there any hazards near me?"*
     - *"What should I do if I encounter flooding?"*
   - Strictly grounded in application data — does NOT fabricate disasters.

---

## 4. Technology Stack
- **Language**: Kotlin 2.2+ (100% Kotlin DSL)
- **UI Framework**: Jetpack Compose with Material Design 3 (M3)
- **Architecture**: Model-View-State with centralized reactive StateFlow repository (`DemoDataRepository`)
- **Map Engine**: Custom Compose Canvas vector renderer (ensures 100% reliability offline without Google Maps API keys)
- **Target SDK**: Android 36 (minSdk 24 - supports 95%+ of active Android devices)

---

## 5. Demonstration & Demo Mode Details

### Which features are real?
- Real-time **Safety Score algorithm** (`SafetyScoreCalculator.kt`).
- Real-time **Route risk engine** (`RouteManager.kt`).
- Interactive **Map canvas renderer** with gesture tap hit-testing and pulsing danger radiuses.
- **Incident reporting engine** that adds new reports to the live reactive StateFlow and updates scores across all screens.
- **Android System Intents** (`ACTION_DIAL` for SOS calling and `ACTION_SEND` for location check-ins and alert broadcasts).
- **Rule-based NLP chat engine** for SafeRoute Assistant (`AssistantEngine.kt`).

### Which features use demo/mock data?
- **Disaster Data**: Simulated regional storm scenario (Main Road flooding, Central Blvd blockage, Industrial fire).
- **Facilities Data**: Mock local hospitals and shelters for reliable, offline hackathon presentation.
- **Map Geometry**: Vector coordinate system normalized for demonstrative display without billing or API keys.

---

## 6. How to Run the Application
1. Clone or open the project in Android Studio (Ladybug or newer).
2. Sync Gradle dependencies.
3. Select an Android Emulator (API 24+) or physical device.
4. Press **Run** (`Shift + F10`).
5. No API keys or external services are needed — Demo Mode is active out of the box!

---

## 7. Step-by-Step Hackathon Demo Walkthrough
1. **Launch App**: View the SafeRoute AI splash screen with tagline.
2. **Home Screen**: Observe the "Moderate Risk" status and destination search box.
3. **Find Safe Route**: Tap *"Find Safe Route"* to view comparison between **Route A** (88/100 SAFE) and **Route B** (52/100 CAUTION).
4. **Inspect Route Risks**: Read why Route B is risky (*"Flooding reported 500 m ahead"*).
5. **Open Hazard Map**: View the visual map canvas with pulsing red/orange flood markers. Tap any marker to open its field report card.
6. **Ask SafeRoute Assistant**: Tap the Assistant tab and ask *"Why is Route B risky?"* or *"What should I do if I encounter flooding?"* to see grounded, reliable answers.
7. **Submit a Report**: Tap *"Report Incident"*, submit a fallen tree report, and watch it appear immediately on the map and alerts list.
8. **Emergency Help**: Tap *"SOS Help"* to see 1-tap emergency calling, nearest shelter bed counts, and location sharing.

---

## 8. Future Improvements
- Integration with live OpenStreetMap / Google Maps SDK when API keys are configured.
- Integration with official National Disaster Management Authority (NDMA) & NOAA alert feeds.
- Offline peer-to-peer mesh networking (Bluetooth LE / Wi-Fi Direct) for communications when cell towers fail.
- Turn-by-turn spoken audio navigation cues for low-visibility emergency driving.
